# -*- coding: utf-8 -*-
"""
Created on Tue Oct  8 12:29:59 2024

@author: USER
"""

import pandas as pd
from sqlalchemy import create_engine
import psycopg2

# Create a database connection
engine = create_engine('postgresql://user:password@localhost:5432/mydatabase')

# Define the SQL query
query = "SELECT * FROM gt_clientdata2"

# Load data into a DataFrame
df = pd.read_sql(query, engine)

# Display the first few rows of the DataFrame
print(df.head())

import os
print(os.getenv('DB_USER'))
print(os.getenv('DB_PASSWORD'))


import psycopg2
import pandas as pd

# Define your connection parameters
conn = psycopg2.connect(
    dbname="GT_ClientData",
    user="postgres",
    password="Ephesians1:3",
    host="localhost",
    port= 5432
)

# Create a cursor object
cursor = conn.cursor()

# Define your SQL query
query = "SELECT * FROM your_table_name"

# Load data into a DataFrame
gt_clientdata = pd.read_sql_query(query, conn)

# Close the cursor and connection
cursor.close()
conn.close()

# Display the DataFrame
print(df.head())

df = cur.fetchall()
df.heatno.mean()

### Reassigning My Variable To gt_clientdata
gt_clientdata = df
del df
print(gt_clientdata)

######### Business Decisions for GT Client Data #########
### First Moment Business Decision, Mean ,Median, Mode ####
gt_clientdata.heatno.mean() #mean

gt_clientdata.heatno.median() #Median

gt_clientdata.heatno.mode() #Mode

from scipy import stats
mode = stats.mode(gt_clientdata.heatno) # Multimodal
print(mode)


#### Second Moment Business Decisions ######
gt_clientdata.heatno.var() # variance
gt_clientdata.heatno.std() # standard deviation
range = max(gt_clientdata.heatno) - min(gt_clientdata.heatno) # range
range

# Third moment business decision
gt_clientdata.heatno.skew()

# Fourth moment business decision
gt_clientdata.heatno.kurt()

from scipy import stats
mode = stats.mode(gt_clientdata.heatno)

print(mode)

######### Business Decisions for #########
### First Moment Business Decision, Mean ,Median, Mode ####
gt_clientdata.inj1_qty.mean() #mean

gt_clientdata.inj1_qty.median() #Median

gt_clientdata.inj1_qty.mode() #Mode

from scipy import stats
mode = stats.mode(gt_clientdata.inj1_qty) # Multimodal
print(mode)


#### Second Moment Business Decisions ######
gt_clientdata.inj1_qty.var() # variance
gt_clientdata.inj1_qty.std() # standard deviation
range = max(gt_clientdata.inj1_qty) - min(gt_clientdata.inj1_qty) # range
range

# Third moment business decision
gt_clientdata.inj1_qty.skew()

# Fourth moment business decision
gt_clientdata.inj1_qty.kurt()


######### Business Decisions for #########
### First Moment Business Decision, Mean ,Median, Mode ####
gt_clientdata.inj2_qty.mean() #mean

gt_clientdata.inj2_qty.median() #Median

gt_clientdata.inj2_qty.mode() #Mode

from scipy import stats
mode = stats.mode(gt_clientdata.inj2_qty) # Multimodal
print(mode)


#### Second Moment Business Decisions ######
gt_clientdata.inj2_qty.var() # variance
gt_clientdata.inj2_qty.std() # standard deviation
range = max(gt_clientdata.inj2_qty) - min(gt_clientdata.inj2_qty) # range
range

# Third moment business decision
gt_clientdata.inj2_qty.skew()

# Fourth moment business decision
gt_clientdata.inj2_qty.kurt()

######### Business Decisions for bsm #########
### First Moment Business Decision, Mean ,Median, Mode ####
gt_clientdata.bsm.mean() #mean

gt_clientdata.bsm.median() #Median

gt_clientdata.bsm.mode() #Mode

from scipy import stats
mode = stats.mode(gt_clientdata.bsm) # Multimodal
print(mode)


#### Second Moment Business Decisions ######
gt_clientdata.bsm.var() # variance
gt_clientdata.bsm.std() # standard deviation
range = max(gt_clientdata.bsm) - min(gt_clientdata.bsm) # range
range

# Third moment business decision
gt_clientdata.bsm.skew()

# Fourth moment business decision
gt_clientdata.bsm.kurt()


######### Business Decisions for skull #########
### First Moment Business Decision, Mean ,Median, Mode ####
gt_clientdata.skull.mean() #mean

gt_clientdata.skull.median() #Median

gt_clientdata.skull.mode() #Mode

from scipy import stats
mode = stats.mode(gt_clientdata.skull) # Multimodal
print(mode)


#### Second Moment Business Decisions ######
gt_clientdata.skull.var() # variance
gt_clientdata.skull.std() # standard deviation
range = max(gt_clientdata.skull) - min(gt_clientdata.skull) # range
range

# Third moment business decision
gt_clientdata.skull.skew()

# Fourth moment business decision
gt_clientdata.skull.kurt()


######### Business Decisions for bp #########
### First Moment Business Decision, Mean ,Median, Mode ####
gt_clientdata.bp.mean() #mean

gt_clientdata.bp.median() #Median

gt_clientdata.bp.mode() #Mode

from scipy import stats
mode = stats.mode(gt_clientdata.bp) # Multimodal
print(mode)


#### Second Moment Business Decisions ######
gt_clientdata.bp.var() # variance
gt_clientdata.bp.std() # standard deviation
range = max(gt_clientdata.bp) - min(gt_clientdata.bp) # range
range

# Third moment business decision
gt_clientdata.skull.skew()

# Fourth moment business decision
gt_clientdata.skull.kurt()

######### Business Decisions for hbi #########
### First Moment Business Decision, Mean ,Median, Mode ####
gt_clientdata.hbi.mean() #mean

gt_clientdata.hbi.median() #Median

gt_clientdata.hbi.mode() #Mode

from scipy import stats
mode = stats.mode(gt_clientdata.hbi) # Multimodal
print(mode)


#### Second Moment Business Decisions ######
gt_clientdata.hbi.var() # variance
gt_clientdata.hbi.std() # standard deviation
range = max(gt_clientdata.hbi) - min(gt_clientdata.hbi) # range
range

# Third moment business decision
gt_clientdata.hbi.skew()

# Fourth moment business decision
gt_clientdata.hbi.kurt()


######### Business Decisions for others #########
### First Moment Business Decision, Mean ,Median, Mode ####
gt_clientdata.others.mean() #mean

gt_clientdata.others.median() #Median

gt_clientdata.others.mode() #Mode

from scipy import stats
mode = stats.mode(gt_clientdata.others) # Multimodal
print(mode)


#### Second Moment Business Decisions ######
gt_clientdata.others.var() # variance

gt_clientdata.others.std() # standard deviation

range = max(gt_clientdata.others) - min(gt_clientdata.others) # range
range

# Third moment business decision
gt_clientdata.others.skew()

# Fourth moment business decision
gt_clientdata.others.kurt()

######### Business Decisions for scrap_qty_mt #########
### First Moment Business Decision, Mean ,Median, Mode ####
gt_clientdata.scrap_qty_mt.mean() #mean

gt_clientdata.scrap_qty_mt.median() #Median

gt_clientdata.scrap_qty_mt.mode() #Mode

from scipy import stats
mode = stats.mode(gt_clientdata.scrap_qty_mt) # Multimodal
print(mode)


#### Second Moment Business Decisions ######
gt_clientdata.scrap_qty_mt.var() # variance

gt_clientdata.scrap_qty_mt.std() # standard deviation

range = max(gt_clientdata.scrap_qty_mt) - min(gt_clientdata.scrap_qty_mt) # range
range

# Third moment business decision
gt_clientdata.scrap_qty_mt.skew()

# Fourth moment business decision
gt_clientdata.scrap_qty_mt.kurt()


######### Business Decisions for pigiron #########
### First Moment Business Decision, Mean ,Median, Mode ####
gt_clientdata.pigiron.mean() #mean

gt_clientdata.pigiron.median() #Median

gt_clientdata.pigiron.mode() #Mode

from scipy import stats
mode = stats.mode(gt_clientdata.pigiront) # Multimodal
print(mode)


#### Second Moment Business Decisions ######
gt_clientdata.pigiron.var() # variance

gt_clientdata.pigiron.std() # standard deviation

range = max(gt_clientdata.pigiron) - min(gt_clientdata.pigiron) # range
range

# Third moment business decision
gt_clientdata.pigiron.skew()

# Fourth moment business decision
gt_clientdata.pigiron.kurt()


######### Business Decisions for dri1_qty_mp_lumps #########
### First Moment Business Decision, Mean ,Median, Mode ####
gt_clientdata.dri1_qty_mt_lumps.mean() #mean

gt_clientdata.dri1_qty_mt_lumps.median() #Median

gt_clientdata.dri1_qty_mt_lumps.mode() #Mode

from scipy import stats
mode = stats.mode(gt_clientdata.dri1_qty_mt_lumps) # Multimodal
print(mode)


#### Second Moment Business Decisions ######
gt_clientdata.dri1_qty_mt_lumps.var() # variance

gt_clientdata.dri1_qty_mt_lumps.std() # standard deviation

range = max(gt_clientdata.dri1_qty_mt_lumps) - min(gt_clientdata.dri1_qty_mt_lumps) # range
range

# Third moment business decision
gt_clientdata.dri1_qty_mt_lumps.skew()

# Fourth moment business decision
gt_clientdata.dri1_qty_mt_lumps.kurt()


######### Business Decisions for dri2_-qty_mt_fines #########
### First Moment Business Decision, Mean ,Median, Mode ####
gt_clientdata.dri2_qty_mt_fines.mean() #mean

gt_clientdata.dri2_qty_mt_fines.median() #Median

gt_clientdata.dri2_qty_mt_fines.mode() #Mode

from scipy import stats
mode = stats.mode(gt_clientdata.dri2_qty_mt_fines) # Multimodal
print(mode)


#### Second Moment Business Decisions ######
gt_clientdata.dri2_qty_mt_fines.var() # variance

gt_clientdata.dri2_qty_mt_fines.std() # standard deviation

range = max(gt_clientdata.dri2_qty_mt_fines) - min(gt_clientdata.dri2_qty_mt_fines) # range
range

# Third moment business decision
gt_clientdata.dri2_qty_mt_fines.skew()

# Fourth moment business decision
gt_clientdata.dri2_qty_mt_fines.kurt()


######### Business Decisions for tot_dri_qty #########
### First Moment Business Decision, Mean ,Median, Mode ####
gt_clientdata.tot_dri_qty.mean() #mean

gt_clientdata.tot_dri_qty.median() #Median

gt_clientdata.tot_dri_qty.mode() #Mode

from scipy import stats
mode = stats.mode(gt_clientdata.tot_dri_qty) # Multimodal
print(mode)


#### Second Moment Business Decisions ######
gt_clientdata.tot_dri_qty.var() # variance

gt_clientdata.tot_dri_qty.std() # standard deviation

range = max(gt_clientdata.tot_dri_qty) - min(gt_clientdata.tot_dri_qty) # range
range

# Third moment business decision
gt_clientdata.tot_dri_qty.skew()

# Fourth moment business decision
gt_clientdata.tot_dri_qty.kurt()

######### Business Decisions for hot_metal_from_mbf #########
### First Moment Business Decision, Mean ,Median, Mode ####
gt_clientdata.hot_metal_from_mbf.mean() #mean

gt_clientdata.hot_metal_from_mbf.median() #Median

gt_clientdata.hot_metal_from_mbf.mode() #Mode

from scipy import stats
mode = stats.mode(gt_clientdata.hot_metal_from_mbf) # Multimodal
print(mode)


#### Second Moment Business Decisions ######
gt_clientdata.hot_metal_from_mbf.var() # variance

gt_clientdata.hot_metal_from_mbf.std() # standard deviation

range = max(gt_clientdata.hot_metal_from_mbf) - min(gt_clientdata.hot_metal_from_mbf) # range
range

# Third moment business decision
gt_clientdata.hot_metal_from_mbf.skew()

# Fourth moment business decision
gt_clientdata.hot_metal_from_mbf.kurt()

######### Business Decisions for total_charge #########
### First Moment Business Decision, Mean ,Median, Mode ####
gt_clientdata.total_charge.mean() #mean

gt_clientdata.total_charge.median() #Median

gt_clientdata.total_charge.mode() #Mode

from scipy import stats
mode = stats.mode(gt_clientdata.total_charge) # Multimodal
print(mode)


#### Second Moment Business Decisions ######
gt_clientdata.total_charge.var() # variance

gt_clientdata.total_charge.std() # standard deviation

range = max(gt_clientdata.total_charge) - min(gt_clientdata.total_charge) # range
range

# Third moment business decision
gt_clientdata.total_charge.skew()

# Fourth moment business decision
gt_clientdata.total_charge.kurt()

######### Business Decisions for hot_heel #########
### First Moment Business Decision, Mean ,Median, Mode ####
gt_clientdata.hot_heel.mean() #mean

gt_clientdata.hot_heel.median() #Median

gt_clientdata.hot_heel.mode() #Mode

from scipy import stats
mode = stats.mode(gt_clientdata.hot_heel) # Multimodal
print(mode)


#### Second Moment Business Decisions ######
gt_clientdata.hot_heel.var() # variance

gt_clientdata.hot_heel.std() # standard deviation

range = max(gt_clientdata.hot_heel) - min(gt_clientdata.hot_heel) # range
range

# Third moment business decision
gt_clientdata.hot_heel.skew()

# Fourth moment business decision
gt_clientdata.hot_heel.kurt()

######### Business Decisions for dolo #########
### First Moment Business Decision, Mean ,Median, Mode ####
gt_clientdata.dolo.mean() #mean

gt_clientdata.dolo.median() #Median

gt_clientdata.dolo.mode() #Mode

from scipy import stats
mode = stats.mode(gt_clientdata.dolo) # Multimodal
print(mode)


#### Second Moment Business Decisions ######
gt_clientdata.dolo.var() # variance

gt_clientdata.dolo.std() # standard deviation

range = max(gt_clientdata.dolo) - min(gt_clientdata.dolo) # range
range

# Third moment business decision
gt_clientdata.dolo.skew()

# Fourth moment business decision
gt_clientdata.dolo.kurt()

######### Business Decisions for dolo1_empty #########
### First Moment Business Decision, Mean ,Median, Mode ####
gt_clientdata.dolo1_empty.mean() #mean

gt_clientdata.dolo1_empty.median() #Median

gt_clientdata.dolo1_empty.mode() #Mode

from scipy import stats
mode = stats.mode(gt_clientdata.dolo1_empty) # Multimodal
print(mode)


#### Second Moment Business Decisions ######
gt_clientdata.dolo1_empty.var() # variance

gt_clientdata.dolo1_empty.std() # standard deviation

range = max(gt_clientdata.dolo1_empty) - min(gt_clientdata.dolo1_empty) # range
range

# Third moment business decision
gt_clientdata.dolo1_empty.skew()

# Fourth moment business decision
gt_clientdata.dolo1_empty.kurt()


######### Business Decisions for tot_lime_qty #########
### First Moment Business Decision, Mean ,Median, Mode ####
gt_clientdata.tot_lime_qty.mean() #mean

gt_clientdata.tot_lime_qty.median() #Median

gt_clientdata.tot_lime_qty.mode() #Mode

from scipy import stats
mode = stats.mode(gt_clientdata.tot_lime_qty) # Multimodal
print(mode)


#### Second Moment Business Decisions ######
gt_clientdata.tot_lime_qty.var() # variance

gt_clientdata.tot_lime_qty.std() # standard deviation

range = max(gt_clientdata.tot_lime_qty) - min(gt_clientdata.tot_lime_qty) # range
range

# Third moment business decision
gt_clientdata.tot_lime_qty.skew()

# Fourth moment business decision
gt_clientdata.tot_lime_qty.kurt()

######### Business Decisions for tap_temp #########
### First Moment Business Decision, Mean ,Median, Mode ####
gt_clientdata.tap_temp.mean() #mean

gt_clientdata.tap_temp.median() #Median

gt_clientdata.tap_temp.mode() #Mode

from scipy import stats
mode = stats.mode(gt_clientdata.tap_temp) # Multimodal
print(mode)


#### Second Moment Business Decisions ######
gt_clientdata.tap_temp.var() # variance

gt_clientdata.tap_temp.std() # standard deviation

range = max(gt_clientdata.tap_temp) - min(gt_clientdata.tap_temp) # range
range

# Third moment business decision
gt_clientdata.tap_temp.skew()

# Fourth moment business decision
gt_clientdata.tap_temp.kurt()

######### Business Decisions for o2act #########
### First Moment Business Decision, Mean ,Median, Mode ####
gt_clientdata.o2act.mean() #mean

gt_clientdata.o2act.median() #Median

gt_clientdata.o2act.mode() #Mode

from scipy import stats
mode = stats.mode(gt_clientdata.o2act) # Multimodal
print(mode)


#### Second Moment Business Decisions ######
gt_clientdata.o2act.var() # variance

gt_clientdata.o2act.std() # standard deviation

range = max(gt_clientdata.o2act) - min(gt_clientdata.o2act) # range
range

# Third moment business decision
gt_clientdata.o2act.skew()

# Fourth moment business decision
gt_clientdata.o2act.kurt()

######### Business Decisions for energy #########
### First Moment Business Decision, Mean ,Median, Mode ####
gt_clientdata.energy.mean() #mean

gt_clientdata.energy.median() #Median

gt_clientdata.energy.mode() #Mode

from scipy import stats
mode = stats.mode(gt_clientdata.energy) # Multimodal
print(mode)


#### Second Moment Business Decisions ######
gt_clientdata.energy.var() # variance

gt_clientdata.energy.std() # standard deviation

range = max(gt_clientdata.energy) - min(gt_clientdata.energy) # range
range

# Third moment business decision
gt_clientdata.energy.skew()

# Fourth moment business decision
gt_clientdata.energy.kurt()


######### Business Decisions for kwh_per_ton #########
### First Moment Business Decision, Mean ,Median, Mode ####
gt_clientdata.kwh_per_ton.mean() #mean

gt_clientdata.kwh_per_ton.median() #Median

gt_clientdata.kwh_per_ton.mode() #Mode

from scipy import stats
mode = stats.mode(gt_clientdata.kwh_per_ton) # Multimodal
print(mode)


#### Second Moment Business Decisions ######
gt_clientdata.kwh_per_ton.var() # variance

gt_clientdata.kwh_per_ton.std() # standard deviation

range = max(gt_clientdata.kwh_per_ton) - min(gt_clientdata.kwh_per_ton) # range
range

# Third moment business decision
gt_clientdata.kwh_per_ton.skew()

# Fourth moment business decision
gt_clientdata.kwh_per_ton.kurt()

#--------------------------------------------------------------#

######### Business Decisions for kwh_per_min #########
### First Moment Business Decision, Mean ,Median, Mode ####
gt_clientdata.kwh_per_min.mean() #mean

gt_clientdata.kwh_per_min.median() #Median

gt_clientdata.kwh_per_min.mode() #Mode

from scipy import stats
mode = stats.mode(gt_clientdata.kwh_per_min) # Multimodal
print(mode)


#### Second Moment Business Decisions ######
gt_clientdata.kwh_per_min.var() # variance

gt_clientdata.kwh_per_min.std() # standard deviation

range = max(gt_clientdata.kwh_per_min) - min(gt_clientdata.kwh_per_min) # range
range

# Third moment business decision
gt_clientdata.kwh_per_min.skew()

# Fourth moment business decision
gt_clientdata.kwh_per_min.kurt()

######### Business Decisions for e1_cur #########
### First Moment Business Decision, Mean ,Median, Mode ####
gt_clientdata.e1_cur.mean() #mean

gt_clientdata.e1_cur.median() #Median

gt_clientdata.e1_cur.mode() #Mode

from scipy import stats
mode = stats.mode(gt_clientdata.e1_cur) #Bimodal # Multimodal
print(mode)


#### Second Moment Business Decisions ######
gt_clientdata.e1_cur.var() # variance

gt_clientdata.e1_cur.std() # standard deviation

range = max(gt_clientdata.e1_cur) - min(gt_clientdata.e1_cur) # range
range

# Third moment business decision
gt_clientdata.e1_cur.skew()

# Fourth moment business decision
gt_clientdata.e1_cur.kurt()


######### Business Decisions for e2_cur #########
### First Moment Business Decision, Mean ,Median, Mode ####
gt_clientdata.e2_cur.mean() #mean

gt_clientdata.e2_cur.median() #Median

gt_clientdata.e2_cur.mode() #Mode

from scipy import stats
mode = stats.mode(gt_clientdata.e2_cur) # Multimodal
print(mode)


#### Second Moment Business Decisions ######
gt_clientdata.e2_cur.var() # variance

gt_clientdata.e2_cur.std() # standard deviation

range = max(gt_clientdata.e2_cur) - min(gt_clientdata.e2_cur) # range
range

# Third moment business decision
gt_clientdata.e2_cur.skew()

# Fourth moment business decision
gt_clientdata.e2_cur.kurt

kurt = stats.kurtosis(gt_clientdata.e2_cur) # Multi kurt
print(kurt)

######## Business Decisions for e3_cur #########
### First Moment Business Decision, Mean ,Median, Mode ####
gt_clientdata.e3_cur.mean() #mean

gt_clientdata.e3_cur.median() #Median

gt_clientdata.e3_cur.mode() #Mode

from scipy import stats
mode = stats.mode(gt_clientdata.e3_cur) #Bimodal # Multimodal
print(mode)


#### Second Moment Business Decisions ######
gt_clientdata.e3_cur.var() # variance

gt_clientdata.e3_cur.std() # standard deviation

range = max(gt_clientdata.e3_cur) - min(gt_clientdata.e3_cur) # range
range

# Third moment business decision
gt_clientdata.e3_cur.skew()

# Fourth moment business decision
gt_clientdata.e3_cur.kurt()


######### Business Decisions for spout #########
### First Moment Business Decision, Mean ,Median, Mode ####
gt_clientdata.spout.mean() #mean

gt_clientdata.spout.median() #Median

gt_clientdata.spout.mode() #Mode

from scipy import stats
mode = stats.mode(gt_clientdata.spout) # Multimodal
print(mode)


#### Second Moment Business Decisions ######
gt_clientdata.spout.var() # variance

gt_clientdata.spout.std() # standard deviation

range = max(gt_clientdata.spout) - min(gt_clientdata.spout) # range
range

# Third moment business decision
gt_clientdata.spout.skew()

# Fourth moment business decision
gt_clientdata.spout.kurt

kurt = stats.kurtosis(gt_clientdata.spout) # Multi kurt
print(kurt)

##-------------------------------------------------------------------------------#

######### Business Decisions for c #########
### First Moment Business Decision, Mean ,Median, Mode ####
gt_clientdata.c.mean() #mean

gt_clientdata.c.median() #Median

gt_clientdata.c.mode() #Mode

from scipy import stats
mode = stats.mode(gt_clientdata.c) # Multimodal
print(mode)


#### Second Moment Business Decisions ######
gt_clientdata.c.var() # variance

gt_clientdata.c.std() # standard deviation

range = max(gt_clientdata.c) - min(gt_clientdata.c) # range
range

# Third moment business decision
gt_clientdata.c.skew()

# Fourth moment business decision
gt_clientdata.c.kurt()

######### Business Decisions for si #########
### First Moment Business Decision, Mean ,Median, Mode ####
gt_clientdata.si.mean() #mean

gt_clientdata.si.median() #Median

gt_clientdata.si.mode() #Mode

from scipy import stats
mode = stats.mode(gt_clientdata.si) #Bimodal # Multimodal
print(mode)


#### Second Moment Business Decisions ######
gt_clientdata.si.var() # variance

gt_clientdata.si.std() # standard deviation

range = max(gt_clientdata.si) - min(gt_clientdata.si) # range
range

# Third moment business decision
gt_clientdata.si.skew()

# Fourth moment business decision
gt_clientdata.si.kurt()


######### Business Decisions for mn #########
### First Moment Business Decision, Mean ,Median, Mode ####
gt_clientdata.mn.mean() #mean

gt_clientdata.mn.median() #Median

gt_clientdata.mn.mode() #Mode

from scipy import stats
mode = stats.mode(gt_clientdata.mn) # Multimodal
print(mode)


#### Second Moment Business Decisions ######
gt_clientdata.mn.var() # variance

gt_clientdata.mn.std() # standard deviation

range = max(gt_clientdata.mn) - min(gt_clientdata.mn) # range
range

# Third moment business decision
gt_clientdata.mn.skew()

# Fourth moment business decision
gt_clientdata.mn.kurt

kurt = stats.kurtosis(gt_clientdata.mn) # Multi kurt
print(kurt)

######## Business Decisions for p #########
### First Moment Business Decision, Mean ,Median, Mode ####
gt_clientdata.p.mean() #mean

gt_clientdata.p.median() #Median

gt_clientdata.p.mode() #Mode

from scipy import stats
mode = stats.mode(gt_clientdata.p) #Bimodal # Multimodal
print(mode)


#### Second Moment Business Decisions ######
gt_clientdata.p.var() # variance

gt_clientdata.p.std() # standard deviation

range = max(gt_clientdata.p) - min(gt_clientdata.p) # range
range

# Third moment business decision
gt_clientdata.p.skew()

# Fourth moment business decision
gt_clientdata.p.kurt()


######### Business Decisions for s #########
### First Moment Business Decision, Mean ,Median, Mode ####
gt_clientdata.s.mean() #mean

gt_clientdata.s.median() #Median

gt_clientdata.s.mode() #Mode

from scipy import stats
mode = stats.mode(gt_clientdata.s) # Multimodal
print(mode)


#### Second Moment Business Decisions ######
gt_clientdata.s.var() # variance

gt_clientdata.s.std() # standard deviation

range = max(gt_clientdata.s) - min(gt_clientdata.s) # range
range

# Third moment business decision
gt_clientdata.s.skew()

# Fourth moment business decision
gt_clientdata.s.kurt

kurt = stats.kurtosis(gt_clientdata.s) # Multi kurt
print(kurt)


##-------------------------------------------------------------------------------#

######### Business Decisions for cu #########
### First Moment Business Decision, Mean ,Median, Mode ####
gt_clientdata.cu.mean() #mean

gt_clientdata.cu.median() #Median

gt_clientdata.cu.mode() #Mode

from scipy import stats
mode = stats.mode(gt_clientdata.cu) # Multimodal
print(mode)


#### Second Moment Business Decisions ######
gt_clientdata.cu.var() # variance

gt_clientdata.cu.std() # standard deviation

range = max(gt_clientdata.cu) - min(gt_clientdata.cu) # range
range

# Third moment business decision
gt_clientdata.cu.skew()

# Fourth moment business decision
gt_clientdata.cu.kurt()

######### Business Decisions for cr #########
### First Moment Business Decision, Mean ,Median, Mode ####
gt_clientdata.cr.mean() #mean

gt_clientdata.cr.median() #Median

gt_clientdata.cr.mode() #Mode

from scipy import stats
mode = stats.mode(gt_clientdata.cr) #Bimodal # Multimodal
print(mode)


#### Second Moment Business Decisions ######
gt_clientdata.cr.var() # variance

gt_clientdata.cr.std() # standard deviation

range = max(gt_clientdata.cr) - min(gt_clientdata.cr) # range
range

# Third moment business decision
gt_clientdata.cr.skew()

# Fourth moment business decision
gt_clientdata.cr.kurt()


######### Business Decisions for ni #########
### First Moment Business Decision, Mean ,Median, Mode ####
gt_clientdata.ni.mean() #mean

gt_clientdata.ni.median() #Median

gt_clientdata.ni.mode() #Mode

from scipy import stats
mode = stats.mode(gt_clientdata.ni) # Multimodal
print(mode)


#### Second Moment Business Decisions ######
gt_clientdata.ni.var() # variance

gt_clientdata.ni.std() # standard deviation

range = max(gt_clientdata.ni) - min(gt_clientdata.ni) # range
range

# Third moment business decision
gt_clientdata.ni.skew()

# Fourth moment business decision
gt_clientdata.ni.kurt

kurt = stats.kurtosis(gt_clientdata.ni) # Multi kurt
print(kurt)

######## Business Decisions for n #########
### First Moment Business Decision, Mean ,Median, Mode ####
gt_clientdata.n.mean() #mean

gt_clientdata.n.median() #Median

gt_clientdata.n.mode() #Mode

from scipy import stats
mode = stats.mode(gt_clientdata.n) #Bimodal # Multimodal
print(mode)


#### Second Moment Business Decisions ######
gt_clientdata.n.var() # variance

gt_clientdata.n.std() # standard deviation

range = max(gt_clientdata.n) - min(gt_clientdata.n) # range
range

# Third moment business decision
gt_clientdata.n.skew()

# Fourth moment business decision
gt_clientdata.n.kurt()


######### Business Decisions for open_c #########
### First Moment Business Decision, Mean ,Median, Mode ####
gt_clientdata.open_c.mean() #mean

gt_clientdata.open_c.median() #Median

gt_clientdata.open_c.mode() #Mode

from scipy import stats
mode = stats.mode(gt_clientdata.open_c) # Multimodal
print(mode)


#### Second Moment Business Decisions ######
gt_clientdata.open_c.var() # variance

gt_clientdata.open_c.std() # standard deviation

range = max(gt_clientdata.open_c) - min(gt_clientdata.open_c) # range
range

# Third moment business decision
gt_clientdata.open_c.skew()

# Fourth moment business decision
gt_clientdata.open_c.kurt

kurt = stats.kurtosis(gt_clientdata.open_c) # Multi kurt
print(kurt)


######### Business Decisions for tap_c #########
### First Moment Business Decision, Mean ,Median, Mode ####
gt_clientdata.tap_c.mean() #mean

gt_clientdata.tap_c.median() #Median

gt_clientdata.tap_c.mode() #Mode

from scipy import stats
mode = stats.mode(gt_clientdata.tap_c) # Multimodal
print(mode)


#### Second Moment Business Decisions ######
gt_clientdata.tap_c.var() # variance

gt_clientdata.tap_c.std() # standard deviation

range = max(gt_clientdata.tap_c) - min(gt_clientdata.tap_c) # range
range

# Third moment business decision
gt_clientdata.tap_c.skew()


######### Business Decisions for it_kg #########
### First Moment Business Decision, Mean ,Median, Mode ####
gt_clientdata.it_kg.mean() #mean

gt_clientdata.it_kg.median() #Median

gt_clientdata.it_kg.mode() #Mode

from scipy import stats
mode = stats.mode(gt_clientdata.it_kg) # Multimodal
print(mode)


#### Second Moment Business Decisions ######
gt_clientdata.it_kg.var() # variance

gt_clientdata.it_kg.std() # standard deviation

range = max(gt_clientdata.it_kg) - min(gt_clientdata.it_kg) # range
range

# Third moment business decision
gt_clientdata.it_kg.skew()

# Fourth moment business decision
gt_clientdata.it_kg.kurt

kurt = stats.kurtosis(gt_clientdata.it_kg) # Multi kurt
print(kurt)


##-------------------------------------------------------------------------------#

######### Business Decisions for static_wt #########
### First Moment Business Decision, Mean ,Median, Mode ####
gt_clientdata.static_wt.mean() #mean

gt_clientdata.static_wt.median() #Median

gt_clientdata.static_wt.mode() #Mode

from scipy import stats
mode = stats.mode(gt_clientdata.static_wt) # Multimodal
print(mode)


#### Second Moment Business Decisions ######
gt_clientdata.static_wt.var() # variance

gt_clientdata.static_wt.std() # standard deviation

range = max(gt_clientdata.static_wt) - min(gt_clientdata.static_wt) # range
range

# Third moment business decision
gt_clientdata.static_wt.skew()

# Fourth moment business decision
gt_clientdata.static_wt.kurt()

######### Business Decisions for lime #########
### First Moment Business Decision, Mean ,Median, Mode ####
gt_clientdata.lime.mean() #mean

gt_clientdata.lime.median() #Median

gt_clientdata.lime.mode() #Mode

from scipy import stats
mode = stats.mode(gt_clientdata.lime) #Bimodal # Multimodal
print(mode)


#### Second Moment Business Decisions ######
gt_clientdata.lime.var() # variance

gt_clientdata.lime.std() # standard deviation

range = max(gt_clientdata.lime) - min(gt_clientdata.lime) # range
range

# Third moment business decision
gt_clientdata.lime.skew()

# Fourth moment business decision
gt_clientdata.lime.kurt()


######### Business Decisions for o2side1 #########
### First Moment Business Decision, Mean ,Median, Mode ####
gt_clientdata.o2side1.mean() #mean

gt_clientdata.o2side1.median() #Median

gt_clientdata.o2side1.mode() #Mode

from scipy import stats
mode = stats.mode(gt_clientdata.o2side1) # Multimodal
print(mode)


#### Second Moment Business Decisions ######
gt_clientdata.o2side1.var() # variance

gt_clientdata.o2side1.std() # standard deviation

range = max(gt_clientdata.o2side1) - min(gt_clientdata.o2side1) # range
range

# Third moment business decision
gt_clientdata.o2side1.skew()

# Fourth moment business decision
gt_clientdata.o2side1.kurt

kurt = stats.kurtosis(gt_clientdata.o2side1) # Multi kurt
print(kurt)

######## Business Decisions for o2side2 #########
### First Moment Business Decision, Mean ,Median, Mode ####
gt_clientdata.o2side2.mean() #mean

gt_clientdata.o2side2.median() #Median

gt_clientdata.o2side2.mode() #Mode

from scipy import stats
mode = stats.mode(gt_clientdata.o2side2) #Bimodal # Multimodal
print(mode)


#### Second Moment Business Decisions ######
gt_clientdata.o2side2.var() # variance

gt_clientdata.o2side2.std() # standard deviation

range = max(gt_clientdata.o2side2) - min(gt_clientdata.o2side2) # range
range

# Third moment business decision
gt_clientdata.o2side2.skew()

# Fourth moment business decision
gt_clientdata.o2side2.kurt()


######### Business Decisions for o2side3 #########
### First Moment Business Decision, Mean ,Median, Mode ####
gt_clientdata.o2side3.mean() #mean

gt_clientdata.o2side3.median() #Median

gt_clientdata.o2side3.mode() #Mode

from scipy import stats
mode = stats.mode(gt_clientdata.o2side3) # Multimodal
print(mode)


#### Second Moment Business Decisions ######
gt_clientdata.o2side3.var() # variance

gt_clientdata.o2side3.std() # standard deviation

range = max(gt_clientdata.o2side3) - min(gt_clientdata.o2side3) # range
range

# Third moment business decision
gt_clientdata.o2side3.skew()

# Fourth moment business decision
gt_clientdata.o2side3.kurt

kurt = stats.kurtosis(gt_clientdata.o2side3) # Multi kurt
print(kurt)


######### Business Decisions for tap_duration #########
### First Moment Business Decision, Mean ,Median, Mode ####
gt_clientdata.tap_duration.mean() #mean

gt_clientdata.tap_duration.median() #Median

gt_clientdata.tap_duration.mode() #Mode

from scipy import stats
mode = stats.mode(gt_clientdata.tap_duration) # Multimodal
print(mode)


#### Second Moment Business Decisions ######
gt_clientdata.tap_duration.var() # variance

gt_clientdata.tap_duration.std() # standard deviation

range = max(gt_clientdata.tap_duration) - min(gt_clientdata.tap_duration) # range
range

# Third moment business decision
gt_clientdata.tap_duration.skew()

# Fourth moment business decision
gt_clientdata.tap_duration.kurt

kurt = stats.kurtosis(gt_clientdata.tap_duration) # Multi kurt
print(kurt)

######## Business Decisions for pour_back_metal #########
### First Moment Business Decision, Mean ,Median, Mode ####
gt_clientdata.pour_back_metal.mean() #mean

gt_clientdata.pour_back_metal.median() #Median

gt_clientdata.pour_back_metal.mode() #Mode

from scipy import stats
mode = stats.mode(gt_clientdata.pour_back_metal) #Bimodal # Multimodal
print(mode)


#### Second Moment Business Decisions ######
gt_clientdata.pour_back_metal.var() # variance

gt_clientdata.pour_back_metal.std() # standard deviation

range = max(gt_clientdata.pour_back_metal) - min(gt_clientdata.pour_back_metal) # range
range

# Third moment business decision
gt_clientdata.pour_back_metal.skew()

# Fourth moment business decision
gt_clientdata.pour_back_metal.kurt()


######### Business Decisions for lm_wt #########
### First Moment Business Decision, Mean ,Median, Mode ####
gt_clientdata.lm_wt.mean() #mean

gt_clientdata.lm_wt.median() #Median

gt_clientdata.lm_wt.mode() #Mode

from scipy import stats
mode = stats.mode(gt_clientdata.lm_wt) # Multimodal
print(mode)


#### Second Moment Business Decisions ######
gt_clientdata.lm_wt.var() # variance

gt_clientdata.lm_wt.std() # standard deviation

range = max(gt_clientdata.lm_wt) - min(gt_clientdata.lm_wt) # range
range

# Third moment business decision
gt_clientdata.lm_wt.skew()

# Fourth moment business decision
gt_clientdata.lm_wt.kurt

kurt = stats.kurtosis(gt_clientdata.lm_wt) # Multi kurt
print(kurt)


######### Business Decisions for production_mt #########
### First Moment Business Decision, Mean ,Median, Mode ####
gt_clientdata.production_mt.mean() #mean

gt_clientdata.production_mt.median() #Median

gt_clientdata.production_mt.mode() #Mode

from scipy import stats
mode = stats.mode(gt_clientdata.production_mt) # Multimodal
print(mode)


#### Second Moment Business Decisions ######
gt_clientdata.production_mt.var() # variance

gt_clientdata.production_mt.std() # standard deviation

range = max(gt_clientdata.production_mt) - min(gt_clientdata.production_mt) # range
range

# Third moment business decision
gt_clientdata.production_mt.skew()

# Fourth moment business decision
gt_clientdata.production_mt.kurt

kurt = stats.kurtosis(gt_clientdata.production_mt) # Multi kurt
print(kurt)

gt_clientdata = gt_clientdata.drop('lime2', axis=1)



#### Outlier Detection and Treatment with Winsorization
import seaborn as sns
from feature_engine.outliers import Winsorizer
sns.boxplot(gt_clientdata.inj1_qty)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                        # choose  IQR rule boundaries or gaussian for mean and std
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['inj1_qty'])
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['inj1_qty'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['inj1_qty']])
sns.boxplot(gt_winsor.inj1_qty)

##### Winsor For inj2_qty
sns.boxplot(gt_clientdata.inj2_qty)

winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['inj2_qty'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['inj2_qty']])

#### Recheck For Outliers
sns.boxplot(gt_winsor.inj2_qty)

####BSM
sns.boxplot(gt_clientdata.bsm)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['bsm'])

gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['bsm']])
sns.boxplot(gt_winsor.bsm)

###SKULL
sns.boxplot(gt_clientdata.bp)
sns.boxplot(gt_clientdata.hbi)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['skull'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['skull']])
sns.boxplot(gt_winsor.skull)

####HBI
sns.boxplot(gt_clientdata.hbi)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['hbi'])

gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['hbi']])

####OTHERS
sns.boxplot(gt_clientdata.others)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['others'])

gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['others']])

sns.boxplot(gt_winsor.others)

##### SRCAP_QTY_MT)
sns.boxplot(gt_clientdata.scrap_qty_mt)

winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['scrap_qty_mt'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['scrap_qty_mt']])

sns.boxplot(gt_winsor.scrap_qty_mt)


##### PIGIRON
sns.boxplot(gt_clientdata.pigiron)

winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['pigiron'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['pigiron']])

#### DRR!_QTY_MT_LUMPS
sns.boxplot(gt_clientdata.dri1_qty_mt_lumps)

winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['dri1_qty_mt_lumps'])

gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['dri1_qty_mt_lumps']])
sns.boxplot(gt_winsor.dri1_qty_mt_lumps)

##### DRI2_QTY_MT_FINES
sns.boxplot(gt_clientdata.dri2_qty_mt_fines)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['dri2_qty_mt_fines'])

gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['dri2_qty_mt_fines']])
sns.boxplot(gt_winsor.dri2_qty_mt_fines)

####TOT_Dri_QTY
sns.boxplot(gt_clientdata.tot_dri_qty)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['tot_dri_qty'])

gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['tot_dri_qty']])
sns.boxplot(gt_winsor.tot_dri_qty)


####Hot_METAL_FROM_MBF
sns.boxplot(gt_clientdata.hot_metal_from_mbf)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['hot_metal_from_mbf'])

gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['hot_metal_from_mbf']])
sns.boxplot(gt_winsor.hot_metal_from_mbf)

###TOTAL_CHARGE
sns.boxplot(gt_clientdata.total_charge)

winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['total_charge'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['total_charge']])
sns.boxplot(gt_winsor.total_charge)


######HOT_HEEL
sns.boxplot(gt_clientdata.hot_heel)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['hot_heel'])

gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['hot_heel']])
sns.boxplot(gt_winsor.hot_heel)

###Dolo
sns.boxplot(gt_clientdata.dolo)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['dolo'])

gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['dolo']])
sns.boxplot(gt_winsor.dolo)

#####dolo1_empty
sns.boxplot(gt_clientdata.dolo1_empty)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['dolo1_empty'])

gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['dolo1_empty']])

sns.boxplot(gt_winsor.dolo1_empty)

#######TOT_LIME_QTY
sns.boxplot(gt_clientdata.tot_lime_qty)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['tot_lime_qty'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['tot_lime_qty']])
sns.boxplot(gt_winsor.tot_lime_qty)

#### TAP_TEMP
sns.boxplot(gt_clientdata.tap_temp)

winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['tap_temp'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['tap_temp']])
sns.boxplot(gt_winsor.tap_temp)

##### O2ACT
sns.boxplot(gt_clientdata.o2act)

winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['o2act'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['o2act']])
sns.boxplot(gt_winsor.o2act)

###ENERGY
sns.boxplot(gt_clientdata.energy)

winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['energy'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['energy']])
sns.boxplot(gt_winsor.energy)

#######  KWH_PER_TON
sns.boxplot(gt_clientdata.kwh_per_ton)

winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['kwh_per_ton'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['kwh_per_ton']])
sns.boxplot(gt_winsor.kwh_per_ton)

##### KWH_PER_MIN
sns.boxplot(gt_clientdata.kwh_per_min)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['kwh_per_min'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['kwh_per_min']])


######KWH_PER_TON
sns.boxplot(gt_clientdata.kwh_per_ton)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['kwh_per_ton'])

gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['kwh_per_ton']])
# Let's see boxplot

###### E1_CUR
sns.boxplot(gt_clientdata.e1_cur)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['e1_cur'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['e1_cur']])
sns.boxplot(gt_winsor.e1_cur)

###### E2_cur
sns.boxplot(gt_clientdata.e2_cur)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['e2_cur'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['e2_cur']])
sns.boxplot(gt_winsor.e2_cur)


##### E3_CUR
sns.boxplot(gt_clientdata.e3_cur)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['e3_cur'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['e3_cur']])
#Lets See Box Plot
sns.boxplot(gt_winsor.e3_cur)

########SPOUT
sns.boxplot(gt_clientdata.spout)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['spout'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['spout']])
sns.boxplot(gt_winsor.spout)

###C
sns.boxplot(gt_clientdata.c)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['c'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['c']])
sns.boxplot(gt_winsor.c)

##### SI
sns.boxplot(gt_clientdata.si)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                     tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['si'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['si']])
##Lets See BoxPlot
sns.boxplot(gt_winsor.si)


##### MN
sns.boxplot(gt_clientdata.mn)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['mn'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['mn']])
sns.boxplot(gt_winsor.mn)

###P
sns.boxplot(gt_clientdata.p)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['p'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['p']])
sns.boxplot(gt_winsor.p)


###S
sns.boxplot(gt_clientdata.s)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['s'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['s']])
sns.boxplot(gt_winsor.s)

####CU
sns.boxplot(gt_clientdata.cu)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['cu'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['cu']])
sns.boxplot(gt_winsor.cu)

#######CR
sns.boxplot(gt_clientdata.cr)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['cr'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['cr']])
sns.boxplot(gt_winsor.cr)

### NI
sns.boxplot(gt_clientdata.ni)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['ni'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['ni']])
sns.boxplot(gt_winsor.ni)

###### N
sns.boxplot(gt_clientdata.n)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['n'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['n']])
sns.boxplot(gt_winsor.n)

#####Open_c
sns.boxplot(gt_clientdata.open_c)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['open_c'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['open_c']])
sns.boxplot(gt_winsor.open_c)

####### Tap_c
sns.boxplot(gt_clientdata.tap_c)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['tap_c'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['tap_c']])
sns.boxplot(gt_winsor.tap_c)

####IT_KG
sns.boxplot(gt_clientdata.it_kg)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['it_kg'])

gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['it_kg']])
sns.boxplot(gt_winsor.it_kg)


##### Static_wt
sns.boxplot(gt_clientdata.static_wt)

winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['static_wt'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['static_wt']])
sns.boxplot(gt_winsor.static_wt)

#### lime
sns.boxplot(gt_clientdata.lime)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['lime'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['lime']])
sns.boxplot(gt_winsor.lime)

###### o2side1
sns.boxplot(gt_clientdata.o2side1)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['o2side1'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['o2side1']])
sns.boxplot(gt_winsor.o2side1)


####o2side2

sns.boxplot(gt_clientdata.o2side2)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['o2side2'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['o2side2']])
sns.boxplot(gt_winsor.o2side2)

#### O2side3
sns.boxplot(gt_clientdata.o2side3)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['o2side3'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['o2side3']])

sns.boxplot(gt_winsor.o2side3)

####TAp_Duration
sns.boxplot(gt_clientdata.tap_duration)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['tap_duration'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['tap_duration']])
sns.boxplot(gt_winsor.tap_duration)

#####POUR_BLACK_METAL
sns.boxplot(gt_clientdata.pour_back_metal)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['pour_back_metal'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['pour_back_metal']])

########LM_MT
sns.boxplot(gt_clientdata.lm_wt)

winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['lm_wt'])

gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['lm_wt']])
sns.boxplot(gt_winsor.lm_wt)

#### Production_mt
sns.boxplot(gt_clientdata.production_mt)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['production_mt'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['production_mt']])
sns.boxplot(gt_winsor.production_mt)



#################### Missing Values - Imputation ###########################
gt_clientdata.isna().sum()

import pandas as pd
import numpy as np
from sklearn.impute import SimpleImputer

# Mode Imputer for section
mode_imputer = SimpleImputer(missing_values = np.nan, strategy = 'most_frequent')
gt_clientdata['section'] = gt_clientdata['section'].astype(str)
gt_clientdata["section"] = pd.DataFrame(mode_imputer.fit_transform(gt_clientdata[["section"]]))
gt_clientdata["section"].isna().sum()


# Mean Imputer for production_mt
mean_imputer = SimpleImputer(missing_values = np.nan, strategy = 'mean')
gt_clientdata["production_mt"] = pd.DataFrame(mean_imputer.fit_transform(gt_clientdata[["production_mt"]]))
gt_clientdata["production_mt"].isna().sum()

#lab_rep_time
gt_clientdata['lab_rep_time'] = gt_clientdata['lab_rep_time'].fillna(value=gt_clientdata['lab_rep_time'].median)
gt_clientdata['lab_rep_time'].isna().sum()

#prev_tap_time
gt_clientdata['prev_tap_time'] = gt_clientdata['prev_tap_time'].fillna(value=gt_clientdata['prev_tap_time'].mean)
gt_clientdata['prev_tap_time'].isna().sum()



###########  TRANSFORMATIONS ##############################
import scipy.stats as stats
import pylab as pylab
import numpy as np

#Checking For Normality For heatno
stats.probplot(gt_clientdata.heatno,dist="norm",plot = pylab)
#Transforming heatno
stats.probplot(np.log(gt_clientdata.heatno),dist="norm",plot=pylab)


#Checking For Normality For inj1_qty
stats.probplot(gt_clientdata.inj1_qty,dist="norm",plot = pylab)
#Transforming inj1_qty
stats.probplot(np.log(gt_clientdata. inj1_qty),dist="norm",plot=pylab)

#Checking For Normality For skull
stats.probplot(gt_clientdata.skull,dist="norm",plot = pylab)
#Transforming skull
stats.probplot(np.log(gt_clientdata. skull),dist="norm",plot=pylab)


#Checking For Normality For bp
stats.probplot(gt_clientdata.bp,dist="norm",plot = pylab)
#Transforming bp
stats.probplot(np.log(gt_clientdata. bp),dist="norm",plot=pylab)

#Checking For Normality For dri2_qty_mt_fines
stats.probplot(gt_clientdata.dri2_qty_mt_fines,dist="norm",plot = pylab)
#Transforming dri2_qty_mt_fines
stats.probplot(np.log(gt_clientdata.dri2_qty_mt_fines),dist="norm",plot=pylab)


#Checking For Normality For tot_dri_qty
stats.probplot(gt_clientdata.tot_dri_qty,dist="norm",plot = pylab)
#Transforming tot_dri_qty
stats.probplot(np.log(gt_clientdata. tot_dri_qty),dist="norm",plot=pylab)

#Checking For Normality For hot_metal_from_mbf
stats.probplot(gt_clientdata.hot_metal_from_mbf,dist="norm",plot = pylab)
#Transforming hot_metal_from_mbf
stats.probplot(np.log(gt_clientdata. hot_metal_from_mbf),dist="norm",plot=pylab)


#Checking For Normality For dolo
stats.probplot(gt_clientdata.dolo,dist="norm",plot = pylab)
#Transforming dolo
stats.probplot(np.log(gt_clientdata. dolo),dist="norm",plot=pylab)

#Checking For Normality For tot_lime_qty
stats.probplot(gt_clientdata.tot_lime_qty,dist="norm",plot = pylab)
#Transforming tot_lime_qty
stats.probplot(np.log(gt_clientdata.tot_lime_qty),dist="norm",plot=pylab)


#Checking For Normality For o2act
stats.probplot(gt_clientdata.o2act,dist="norm",plot = pylab)
#Transforming o2act
stats.probplot(np.log(gt_clientdata. o2act),dist="norm",plot=pylab)

#Checking For Normality For e1_cur
stats.probplot(gt_clientdata.e1_cur,dist="norm",plot = pylab)
#Transforming e1_cur
stats.probplot(np.log(gt_clientdata. e1_cur),dist="norm",plot=pylab)


#Checking For Normality For e2_cur
stats.probplot(gt_clientdata.e2_cur,dist="norm",plot = pylab)
#Transforming e2_cur
stats.probplot(np.log(gt_clientdata. e2_cur),dist="norm",plot=pylab)

#Checking For Normality For e3_cur
stats.probplot(gt_clientdata.e3_cur,dist="norm",plot=pylab)
#Transforming e3_cur
stats.probplot(np.log(gt_clientdata. e3_cur),dist="norm",plot=pylab)

#Checking For Normality For prev_tap_time
stats.probplot(gt_clientdata.prev_tap_time,plot=pylab)
#Transforming e3_cur
stats.probplot(np.log(gt_clientdata. e3_cur),dist="norm",plot=pylab)


#####################TYPE CASTING #########################
### Melt_Time,tt_time,ta_time
import pandas as pd
from datetime import timedelta


# Convert float to integer seconds
gt_clientdata['melt_time)'] = gt_clientdata['melt_time'].round().astype(int)
melt_timeMELT_TIME (Melting Time)' to a time data type (HH:MM:SS)
gt_clientdata['melt_time (HH:MM:SS)'] = gt_clientdata['melt_time'].apply(lambda x: str(timedelta(seconds=x)))

# Convert float to integer seconds
gt_clientdata['ta_time)'] = gt_clientdata['ta_time'].round().astype(int)

# Convert 'ta_time' to a time data type (HH:MM:SS)
gt_clientdata['ta_time (HH:MM:SS)'] = gt_clientdata['ta_time'].apply(lambda x: str(timedelta(seconds=x)))

# Convert float to integer seconds
gt_clientdata['tt_time)'] = gt_clientdata['tt_time'].round().astype(int)

# Convert 'tt_time' to a time data type (HH:MM:SS)
gt_clientdata['tt_time'] = gt_clientdata['tt_time'].apply(lambda x: str(timedelta(seconds=x)))



#### Outlier Detection and Treatment with Winsorization######################
import seaborn as sns
from feature_engine.outliers import Winsorizer
sns.boxplot(gt_clientdata.inj1_qty)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                        # choose  IQR rule boundaries or gaussian for mean and std
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['inj1_qty'])
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['inj1_qty'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['inj1_qty']])
sns.boxplot(gt_winsor.inj1_qty)

##### Winsor For inj2_qty
sns.boxplot(gt_clientdata.inj2_qty)

winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['inj2_qty'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['inj2_qty']])

#### Recheck For Outliers
sns.boxplot(gt_winsor.inj2_qty)

####BSM
sns.boxplot(gt_clientdata.bsm)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['bsm'])

gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['bsm']])
sns.boxplot(gt_winsor.bsm)

###SKULL
sns.boxplot(gt_clientdata.bp)
sns.boxplot(gt_clientdata.hbi)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['skull'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['skull']])
sns.boxplot(gt_winsor.skull)

####HBI
sns.boxplot(gt_clientdata.hbi)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['hbi'])

gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['hbi']])

####OTHERS
sns.boxplot(gt_clientdata.others)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['others'])

gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['others']])

sns.boxplot(gt_winsor.others)

##### SRCAP_QTY_MT)
sns.boxplot(gt_clientdata.scrap_qty_mt)

winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['scrap_qty_mt'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['scrap_qty_mt']])

sns.boxplot(gt_winsor.scrap_qty_mt)


##### PIGIRON
sns.boxplot(gt_clientdata.pigiron)

winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['pigiron'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['pigiron']])

#### DRR!_QTY_MT_LUMPS
sns.boxplot(gt_clientdata.dri1_qty_mt_lumps)

winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['dri1_qty_mt_lumps'])

gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['dri1_qty_mt_lumps']])
sns.boxplot(gt_winsor.dri1_qty_mt_lumps)

##### DRI2_QTY_MT_FINES
sns.boxplot(gt_clientdata.dri2_qty_mt_fines)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['dri2_qty_mt_fines'])

gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['dri2_qty_mt_fines']])
sns.boxplot(gt_winsor.dri2_qty_mt_fines)

####TOT_Dri_QTY
sns.boxplot(gt_clientdata.tot_dri_qty)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['tot_dri_qty'])

gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['tot_dri_qty']])
sns.boxplot(gt_winsor.tot_dri_qty)


####Hot_METAL_FROM_MBF
sns.boxplot(gt_clientdata.hot_metal_from_mbf)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['hot_metal_from_mbf'])

gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['hot_metal_from_mbf']])
sns.boxplot(gt_winsor.hot_metal_from_mbf)

###TOTAL_CHARGE
sns.boxplot(gt_clientdata.total_charge)

winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['total_charge'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['total_charge']])
sns.boxplot(gt_winsor.total_charge)


######HOT_HEEL
sns.boxplot(gt_clientdata.hot_heel)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['hot_heel'])

gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['hot_heel']])
sns.boxplot(gt_winsor.hot_heel)

###Dolo
sns.boxplot(gt_clientdata.dolo)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['dolo'])

gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['dolo']])
sns.boxplot(gt_winsor.dolo)

#####dolo1_empty
sns.boxplot(gt_clientdata.dolo1_empty)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['dolo1_empty'])

gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['dolo1_empty']])

sns.boxplot(gt_winsor.dolo1_empty)

#######TOT_LIME_QTY
sns.boxplot(gt_clientdata.tot_lime_qty)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['tot_lime_qty'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['tot_lime_qty']])
sns.boxplot(gt_winsor.tot_lime_qty)

#### TAP_TEMP
sns.boxplot(gt_clientdata.tap_temp)

winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['tap_temp'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['tap_temp']])
sns.boxplot(gt_winsor.tap_temp)

##### O2ACT
sns.boxplot(gt_clientdata.o2act)

winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['o2act'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['o2act']])
sns.boxplot(gt_winsor.o2act)

###ENERGY
sns.boxplot(gt_clientdata.energy)

winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['energy'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['energy']])
sns.boxplot(gt_winsor.energy)

#######  KWH_PER_TON
sns.boxplot(gt_clientdata.kwh_per_ton)

winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['kwh_per_ton'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['kwh_per_ton']])
sns.boxplot(gt_winsor.kwh_per_ton)

##### KWH_PER_MIN
sns.boxplot(gt_clientdata.kwh_per_min)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['kwh_per_min'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['kwh_per_min']])


######KWH_PER_TON
sns.boxplot(gt_clientdata.kwh_per_ton)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['kwh_per_ton'])

gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['kwh_per_ton']])
# Let's see boxplot

###### E1_CUR
sns.boxplot(gt_clientdata.e1_cur)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['e1_cur'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['e1_cur']])
sns.boxplot(gt_winsor.e1_cur)

###### E2_cur
sns.boxplot(gt_clientdata.e2_cur)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['e2_cur'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['e2_cur']])
sns.boxplot(gt_winsor.e2_cur)


##### E3_CUR
sns.boxplot(gt_clientdata.e3_cur)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['e3_cur'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['e3_cur']])
#Lets See Box Plot
sns.boxplot(gt_winsor.e3_cur)

########SPOUT
sns.boxplot(gt_clientdata.spout)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['spout'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['spout']])
sns.boxplot(gt_winsor.spout)

###C
sns.boxplot(gt_clientdata.c)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['c'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['c']])
sns.boxplot(gt_winsor.c)

##### SI
sns.boxplot(gt_clientdata.si)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                     tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['si'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['si']])
##Lets See BoxPlot
sns.boxplot(gt_winsor.si)


##### MN
sns.boxplot(gt_clientdata.mn)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['mn'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['mn']])
sns.boxplot(gt_winsor.mn)

###P
sns.boxplot(gt_clientdata.p)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['p'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['p']])
sns.boxplot(gt_winsor.p)


###S
sns.boxplot(gt_clientdata.s)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['s'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['s']])
sns.boxplot(gt_winsor.s)

####CU
sns.boxplot(gt_clientdata.cu)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['cu'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['cu']])
sns.boxplot(gt_winsor.cu)

#######CR
sns.boxplot(gt_clientdata.cr)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['cr'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['cr']])
sns.boxplot(gt_winsor.cr)

### NI
sns.boxplot(gt_clientdata.ni)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['ni'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['ni']])
sns.boxplot(gt_winsor.ni)

###### N
sns.boxplot(gt_clientdata.n)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['n'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['n']])
sns.boxplot(gt_winsor.n)

#####Open_c
sns.boxplot(gt_clientdata.open_c)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['open_c'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['open_c']])
sns.boxplot(gt_winsor.open_c)

####### Tap_c
sns.boxplot(gt_clientdata.tap_c)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['tap_c'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['tap_c']])
sns.boxplot(gt_winsor.tap_c)

####IT_KG
sns.boxplot(gt_clientdata.it_kg)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['it_kg'])

gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['it_kg']])
sns.boxplot(gt_winsor.it_kg)


##### Static_wt
sns.boxplot(gt_clientdata.static_wt)

winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['static_wt'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['static_wt']])
sns.boxplot(gt_winsor.static_wt)

#### lime
sns.boxplot(gt_clientdata.lime)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['lime'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['lime']])
sns.boxplot(gt_winsor.lime)

###### o2side1
sns.boxplot(gt_clientdata.o2side1)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['o2side1'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['o2side1']])
sns.boxplot(gt_winsor.o2side1)


####o2side2

sns.boxplot(gt_clientdata.o2side2)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['o2side2'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['o2side2']])
sns.boxplot(gt_winsor.o2side2)

#### O2side3
sns.boxplot(gt_clientdata.o2side3)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['o2side3'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['o2side3']])

sns.boxplot(gt_winsor.o2side3)

####TAp_Duration
sns.boxplot(gt_clientdata.tap_duration)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['tap_duration'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['tap_duration']])
sns.boxplot(gt_winsor.tap_duration)

#####POUR_BLACK_METAL
sns.boxplot(gt_clientdata.pour_back_metal)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['pour_back_metal'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['pour_back_metal']])

########LM_MT
sns.boxplot(gt_clientdata.lm_wt)

winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['lm_wt'])

gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['lm_wt']])
sns.boxplot(gt_winsor.lm_wt)

#### Production_mt
sns.boxplot(gt_clientdata.production_mt)
winsor_iqr = Winsorizer(capping_method = 'iqr', 
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5, 
                          variables = ['production_mt'])
gt_winsor = winsor_iqr.fit_transform(gt_clientdata[['production_mt']])
sns.boxplot(gt_winsor.production_mt)












