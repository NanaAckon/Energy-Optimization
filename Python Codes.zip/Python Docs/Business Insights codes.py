# -*- coding: utf-8 -*-
"""
Created on Thu Oct 10 18:22:38 2024

@author: USER
"""

######### Business Insights ##################

import pandas as pd


# 1. How many types of grades of steel are present in my dataset?
grades_of_steel = gt_clientdata['grade'].nunique()
print(f"Number of grades of steel: {grades_of_steel}")

# 2. For manufacturing these types of grades of steel which types of raw materials are mixed together and how many?
raw_materials_columns = ['inj1_qty', 'inj2_qty', 'bsm', 'skull', 'bp', 'hbi', 'others', 
                         'scrap_qty_mt', 'pigiron', 'dri1_qty_mt_lumps', 'dri2_qty_mt_fines', 'tot_dri_qty', 
                         'hot_metal_from_mbf']
raw_materials_per_grade = gt_clientdata.groupby('grade')[raw_materials_columns].count()
print("Raw materials per grade of steel:\n", raw_materials_per_grade)

 # Calculating total raw materials used per grade
gt_clientdata['Total_Raw_Materials'] = gt_clientdata[raw_materials_columns].sum(axis=1)
total_raw_materials_per_grade = gt_clientdata.groupby('grade')['Total_Raw_Materials'].sum()

  # Identifying the grade using the most and least raw materials
most_raw_materials_grade = total_raw_materials_per_grade.idxmax()
least_raw_materials_grade = total_raw_materials_per_grade.idxmin()

print(f"Grade using the most raw materials: {most_raw_materials_grade}")
print(f"Grade using the least raw materials: {least_raw_materials_grade}")


#3. Average Energy Consumption per Grade: Which grade has the highest average energy consumption?
avg_energy_per_grade = gt_clientdata.groupby('grade')['energy'].mean()
print("Average energy consumption per grade:\n", avg_energy_per_grade

# 4. Which grade of steel during manufacturing process consumes more energy or electricity?
most_energy_consuming_grade = gt_clientdata.groupby('grade')['energy'].sum().idxmax()
print(f"Grade of steel consuming the most energy: {most_energy_consuming_grade}")

# 5. Which grades of steel during manufacturing process consumes less energy or electricity?
least_energy_consuming_grade = gt_clientdata.groupby('grade')['energy'].sum().idxmin()
print(f"Grade of steel consuming the least energy: {least_energy_consuming_grade}")


# 6. Which grade brings about the maximum production?
max_production_grade = gt_clientdata.groupby('grade')['production_mt'].sum().idxmax()
print(f"Grade of steel with maximum production: {max_production_grade}")



#7.Production Time Analysis: Determine the average melting and total cycle time per grade.
avg_melt_time_per_grade = gt_clientdata.groupby('grade')['melt_time'].mean()
avg_cycle_time_per_grade = gt_clientdata.groupby('grade')['tt_time'].mean()
print("Average melting time per grade:\n", avg_melt_time_per_grade)
        

# Shift Effeciency
# Group by 'section_ic' and sum the 'ENERGY (Energy Consumption)' column
energy_consumption_per_shift = gt_clientdata.groupby('section_ic')['energy'].sum()

# Identify the shift with the maximum energy consumption
shift_max_energy = energy_consumption_per_shift.idxmax()
max_energy = energy_consumption_per_shift.max()

print(f"Shift with the highest energy consumption: {shift_max_energy} with {max_energy} units of energy consumed")

#Electrode Efficiency: Assess which electrode current levels correlate with optimal energy use and production.
electrode_efficiency = gt_clientdata.groupby('grade')[['e1_cur', 'e2_cur', 'e3_cur', 'energy', 'production_mt']].mean()
print("Electrode efficiency per grade:\n", electrode_efficiency)

#Temperature Impact: Understand how tapping temperatures (TAP_TEMP) influence energy consumption and production quality.
temp_impact = gt_clientdata.groupby('grade')[['tap_temp', 'energy', 'production_mt']].mean()
print("Temperature impact on energy and production:\n", temp_impact)

#Oxygen Activity: Analyze the effect of oxygen activity levels (O2ACT) on production efficiency and energy use.
oxygen_activity_impact = gt_clientdata.groupby('grade')[['o2act', 'energy', 'production_mt']].mean()
print("Oxygen activity impact on energy and production:\n", oxygen_activity_impact)
