CREATE TABLE gt_clientdata(SRNO Numeric,
    DATETIME Date,
    HEATNO Numeric,
    GRADE VARCHAR(20),
    SECTION VARCHAR(10),
    SECTION_IC VARCHAR(10),
    SI_EAF Varchar(50),
    INJ1_QTY Numeric,
    INJ2_QTY Numeric,
    BSM Numeric,
    SKULL Numeric,
    BP Numeric,
    HBI Numeric,
    OTHERS Numeric,
    SCRAP_QTY_MT Numeric,
    PIGIRON Numeric,
    DRI1_QTY_MT_LUMPS Numeric,
    DRI2_QTY_MT_FINES Numeric,
    TOT_DRI_QTY Numeric,
    HOT_METAL_FROM_MBF Numeric,
    TOTAL_CHARGE Numeric,
    HOT_HEEL Numeric,
    DOLO Numeric,
    DOLO1_EMPTY Numeric,
    TOT_LIME_QTY Numeric,
    TAP_TEMP Numeric,
    O2ACT Numeric,
    ENERGY Numeric,
    KWH_PER_TON Numeric,
    KWH_PER_MIN Numeric,
    MELT_TIME Numeric,
    TA_TIME Numeric,
    TT_TIME Numeric,
    POW_ON_TIME Time,
    TAPPING_TIME Time,
    E1_CUR Numeric,
    E2_CUR Numeric,
    E3_CUR Numeric,
    SPOUT Numeric,
    LAB_REP_TIME Time,
    C Numeric,
    SI Numeric,
    MN NUMERIC,
    P NUMERIC,
    S NUMERIC,
    CU Numeric,
    CR Numeric,
    NI Numeric,
    N Numeric,
    OPEN_C Numeric,
    TAP_C Numeric,
    IT_KG Numeric,
    BUCKET_NO Numeric,
    STATIC_WT Numeric,
    LIME Numeric,
    LIME2 Numeric,
    O2SIDE1 Numeric,
    O2SIDE2 Numeric,
    O2SIDE3 Numeric,
    PREV_TAP_TIME Time,
    TAP_DURATION Numeric,
    POUR_BACK_METAL Numeric,
    LM_WT Numeric,
    PRODUCTION_MT Numeric
);


Select * from gt_clientdata

-- First Moment Business Decision 
--Heatno Mean 
SELECT AVG(heatno) AS mean_heatno
FROM gt_clientdata;

--MEDIAN
SELECT heatno AS median_experience
FROM (SELECT heatno, ROW_NUMBER() OVER (ORDER BY heatno) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM gt_clientdata
) AS subquery
WHERE row_num = (total_count + 1) / 2 OR row_num = (total_count + 2) / 2;  

--mode
 SELECT heatno AS mode_heatno
FROM (
    SELECT heatno, COUNT(*) AS frequency
    FROM gt_clientdata
    GROUP BY heatno
    ORDER BY frequency DESC
    LIMIT 1
) AS subquery;

--Second Moment Business Decision/Measures of Dispersion
--Variance
SELECT VARIANCE(heatno) AS heatno_variance
FROM gt_clientdata;

--Standard Deviation 
SELECT STDDEV(heatno) AS heatno_stddev
FROM gt_clientdata;

# Range
SELECT MAX(heatno) - MIN(heatno) AS heatno_range
FROM gt_clientdata;


--Third and Fourth Moment Business Decision
-- skewness and kurkosis 

SELECT
    (
        SUM(POWER(heatno - (SELECT AVG(heatno) FROM gt_clientdata), 3)) / 
        (COUNT(*) * POWER((SELECT STDDEV(heatno) FROM gt_clientdata), 3))
    ) AS skewness,
    (
        (SUM(POWER(heatno - (SELECT AVG(heatno) FROM gt_clientdata), 4)) / 
        (COUNT(*) * POWER((SELECT STDDEV(heatno) FROM gt_clientdata), 4))) - 3
    ) AS kurtosis
FROM gt_clientdata

-------------------------------------------------------------------------------------------------
--- Grade Mode
SELECT grade AS mode_grade
FROM (
    SELECT grade, COUNT(*) AS frequency
    FROM gt_clientdata
    GROUP BY grade
    ORDER BY frequency DESC
    LIMIT 1
) AS subquery;
-------------------------------------------------------------------------------------------------
--- section Mode
SELECT section AS mode_grade
FROM (
    SELECT section, COUNT(*) AS frequency
    FROM gt_clientdata
    GROUP BY section
    ORDER BY frequency DESC
    LIMIT 1
) AS subquery;

-------------------------------------------------------------------------------------------------
--section Mode
SELECT section_ic AS mode_grade
FROM (
    SELECT section_ic, COUNT(*) AS frequency
    FROM gt_clientdata
    GROUP BY section_ic
    ORDER BY frequency DESC
    LIMIT 1
) AS subquery;

-------------------------------------------------------------------------------------------------
-- Mode for si_eaf
SELECT si_eaf AS mode_grade
FROM (
    SELECT si_eaf, COUNT(*) AS frequency
    FROM gt_clientdata
    GROUP BY si_eaf
    ORDER BY frequency DESC
    LIMIT 1
) AS subquery;

-------------------------------------------------------------------------------------------------
-- First Moment Business Decision 
-- inj1_qty Mean 
SELECT AVG(inj1_qty) AS mean_inj1_qty
FROM gt_clientdata;

--MEDIAN
SELECT inj1_qty AS median_inj1_qty
FROM (SELECT inj1_qty, ROW_NUMBER() OVER (ORDER BY inj1_qty) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM gt_clientdata
) AS subquery
WHERE row_num = (total_count + 1) / 2 OR row_num = (total_count + 2) / 2;  

--mode
 SELECT inj1_qty AS mode_inj1_qty
FROM (
    SELECT inj1_qty, COUNT(*) AS frequency
    FROM gt_clientdata
    GROUP BY inj1_qty
    ORDER BY frequency DESC
    LIMIT 1
) AS subquery;

--Second Moment Business Decision/Measures of Dispersion
--Variance
SELECT VARIANCE(inj1_qty) AS inj1_qty_variance
FROM gt_clientdata;

--Standard Deviation 
SELECT STDDEV(inj1_qty) AS inj1_qty_stddev
FROM gt_clientdata;

# Range
SELECT MAX(inj1_qty) - MIN(inj1_qty) AS inj1_qty_range
FROM gt_clientdata;


--Third and Fourth Moment Business Decision
-- skewness and kurkosis 

SELECT
    (
        SUM(POWER(inj1_qty - (SELECT AVG(inj1_qty) FROM gt_clientdata), 3)) / 
        (COUNT(*) * POWER((SELECT STDDEV(inj1_qty) FROM gt_clientdata), 3))
    ) AS skewness,
    (
        (SUM(POWER(inj1_qty - (SELECT AVG(inj1_qty) FROM gt_clientdata), 4)) / 
        (COUNT(*) * POWER((SELECT STDDEV(inj1_qty) FROM gt_clientdata), 4))) - 3
    ) AS kurtosis
FROM gt_clientdata
-------------------------------------------------------------------------------------------------
-- First Moment Business Decision 
-- inj2_qty Mean 
SELECT AVG(inj2_qty) AS mean_inj2_qty
FROM gt_clientdata;

--MEDIAN
SELECT inj2_qty AS median_inj2_qty
FROM (SELECT inj2_qty, ROW_NUMBER() OVER (ORDER BY inj2_qty) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM gt_clientdata
) AS subquery
WHERE row_num = (total_count + 1) / 2 OR row_num = (total_count + 2) / 2;  

--mode
 SELECT inj2_qty AS mode_inj2_qty
FROM (
    SELECT inj2_qty, COUNT(*) AS frequency
    FROM gt_clientdata
    GROUP BY inj2_qty
    ORDER BY frequency DESC
    LIMIT 1
) AS subquery;

--Second Moment Business Decision/Measures of Dispersion
--Variance
SELECT VARIANCE(inj2_qty) AS inj2_qty_variance
FROM gt_clientdata;

--Standard Deviation 
SELECT STDDEV(inj2_qty) AS inj2_qty_stddev
FROM gt_clientdata;

# Range
SELECT MAX(inj2_qty) - MIN(inj2_qty) AS inj2_qty_range
FROM gt_clientdata;


--Third and Fourth Moment Business Decision
-- skewness and kurkosis 

SELECT
    (
        SUM(POWER(inj2_qty - (SELECT AVG(inj2_qty) FROM gt_clientdata), 3)) / 
        (COUNT(*) * POWER((SELECT STDDEV(inj2_qty) FROM gt_clientdata), 3))
    ) AS skewness,
    (
        (SUM(POWER(inj2_qty - (SELECT AVG(inj2_qty) FROM gt_clientdata), 4)) / 
        (COUNT(*) * POWER((SELECT STDDEV(inj2_qty) FROM gt_clientdata), 4))) - 3
    ) AS kurtosis
FROM gt_clientdata
-------------------------------------------------------------------------------------------------
-- First Moment Business Decision 
-- bsm Mean 
SELECT AVG(bsm) AS mean_bsm
FROM gt_clientdata;

--MEDIAN
SELECT bsm AS median_bsm
FROM (SELECT bsm, ROW_NUMBER() OVER (ORDER BY bsm) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM gt_clientdata
) AS subquery
WHERE row_num = (total_count + 1) / 2 OR row_num = (total_count + 2) / 2;  

--mode
 SELECT bsm AS mode_bsm
FROM (
    SELECT bsm, COUNT(*) AS frequency
    FROM gt_clientdata
    GROUP BY bsm
    ORDER BY frequency DESC
    LIMIT 1
) AS subquery;

--Second Moment Business Decision/Measures of Dispersion
--Variance
SELECT VARIANCE(bsm) AS bsm_variance
FROM gt_clientdata;

--Standard Deviation 
SELECT STDDEV(bsm) AS bsm_stddev
FROM gt_clientdata;

# Range
SELECT MAX(bsm) - MIN(bsm) AS bsm_range
FROM gt_clientdata;


--Third and Fourth Moment Business Decision
-- skewness and kurkosis 

SELECT
    (
        SUM(POWER(bsm - (SELECT AVG(bsm) FROM gt_clientdata), 3)) / 
        (COUNT(*) * POWER((SELECT STDDEV(bsm) FROM gt_clientdata), 3))
    ) AS skewness,
    (
        (SUM(POWER(bsm - (SELECT AVG(bsm) FROM gt_clientdata), 4)) / 
        (COUNT(*) * POWER((SELECT STDDEV(bsm) FROM gt_clientdata), 4))) - 3
    ) AS kurtosis
FROM gt_clientdata
-------------------------------------------------------------------------------------------------
-- First Moment Business Decision 
-- Skull Mean 
SELECT AVG(skull) AS mean_skull
FROM gt_clientdata;

--MEDIAN
SELECT skull AS median_skull
FROM (SELECT skull, ROW_NUMBER() OVER (ORDER BY skull) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM gt_clientdata
) AS subquery
WHERE row_num = (total_count + 1) / 2 OR row_num = (total_count + 2) / 2;  

--mode
 SELECT skull AS mode_skull
FROM (
    SELECT skull, COUNT(*) AS frequency
    FROM gt_clientdata
    GROUP BY skull
    ORDER BY frequency DESC
    LIMIT 1
) AS subquery;

--Second Moment Business Decision/Measures of Dispersion
--Variance
SELECT VARIANCE(skull) AS skull_variance
FROM gt_clientdata;

--Standard Deviation 
SELECT STDDEV(skull) AS skull_stddev
FROM gt_clientdata;

# Range
SELECT MAX(skull) - MIN(skull) AS skull_range
FROM gt_clientdata;


--Third and Fourth Moment Business Decision
-- skewness and kurkosis 

SELECT
    (
        SUM(POWER(skull - (SELECT AVG(skull) FROM gt_clientdata), 3)) / 
        (COUNT(*) * POWER((SELECT STDDEV(skull) FROM gt_clientdata), 3))
    ) AS skewness,
    (
        (SUM(POWER(skull - (SELECT AVG(skull) FROM gt_clientdata), 4)) / 
        (COUNT(*) * POWER((SELECT STDDEV(skull) FROM gt_clientdata), 4))) - 3
    ) AS kurtosis
FROM gt_clientdata
-------------------------------------------------------------------------------------------------

-- First Moment Business Decision 
-- bp Mean 
SELECT AVG(bp) AS mean_bp
FROM gt_clientdata;

--MEDIAN
SELECT bp AS median_bp
FROM (SELECT bp, ROW_NUMBER() OVER (ORDER BY bp) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM gt_clientdata
) AS subquery
WHERE row_num = (total_count + 1) / 2 OR row_num = (total_count + 2) / 2;  

--mode
 SELECT bp AS mode_bp
FROM (
    SELECT bp, COUNT(*) AS frequency
    FROM gt_clientdata
    GROUP BY bp
    ORDER BY frequency DESC
    LIMIT 1
) AS subquery;

--Second Moment Business Decision/Measures of Dispersion
--Variance
SELECT VARIANCE(bp) AS bp_variance
FROM gt_clientdata;

--Standard Deviation 
SELECT STDDEV(bp) AS bp_stddev
FROM gt_clientdata;

# Range
SELECT MAX(bp) - MIN(bp) AS bp_range
FROM gt_clientdata;


--Third and Fourth Moment Business Decision
-- skewness and kurkosis 

SELECT
    (
        SUM(POWER(bp - (SELECT AVG(bp) FROM gt_clientdata), 3)) / 
        (COUNT(*) * POWER((SELECT STDDEV(bp) FROM gt_clientdata), 3))
    ) AS skewness,
    (
        (SUM(POWER(bp - (SELECT AVG(bp) FROM gt_clientdata), 4)) / 
        (COUNT(*) * POWER((SELECT STDDEV(bp) FROM gt_clientdata), 4))) - 3
    ) AS kurtosis
FROM gt_clientdata

-------------------------------------------------------------------------------------------------

-- First Moment Business Decision 
-- hbi Mean 
SELECT AVG(hbi) AS mean_bp
FROM gt_clientdata;

--MEDIAN
SELECT hbi AS median_hbi
FROM (SELECT hbi, ROW_NUMBER() OVER (ORDER BY hbi) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM gt_clientdata
) AS subquery
WHERE row_num = (total_count + 1) / 2 OR row_num = (total_count + 2) / 2;  

--mode
 SELECT hbi AS mode_hbi
FROM (
    SELECT hbi, COUNT(*) AS frequency
    FROM gt_clientdata
    GROUP BY hbi
    ORDER BY frequency DESC
    LIMIT 1
) AS subquery;

--Second Moment Business Decision/Measures of Dispersion
--Variance
SELECT VARIANCE(hbi) AS hbi_variance
FROM gt_clientdata;

--Standard Deviation 
SELECT STDDEV(hbi) AS hbi_stddev
FROM gt_clientdata;

# Range
SELECT MAX(hbi) - MIN(hbi) AS hbi_range
FROM gt_clientdata;


--Third and Fourth Moment Business Decision
-- skewness and kurkosis 

SELECT
    (
        SUM(POWER(hbi - (SELECT AVG(hbi) FROM gt_clientdata), 3)) / 
        (COUNT(*) * POWER((SELECT STDDEV(hbi) FROM gt_clientdata), 3))
    ) AS skewness,
    (
        (SUM(POWER(hbi - (SELECT AVG(hbi) FROM gt_clientdata), 4)) / 
        (COUNT(*) * POWER((SELECT STDDEV(hbi) FROM gt_clientdata), 4))) - 3
    ) AS kurtosis
FROM gt_clientdata
---------------------------------------------------------------------------
-- First Moment Business Decision 
-- others Mean 
SELECT AVG(others) AS mean_bp
FROM gt_clientdata;

--MEDIAN
SELECT others AS median_hbi
FROM (SELECT others, ROW_NUMBER() OVER (ORDER BY others) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM gt_clientdata
) AS subquery
WHERE row_num = (total_count + 1) / 2 OR row_num = (total_count + 2) / 2;  

--mode
 SELECT others AS mode_hbi
FROM (
    SELECT others, COUNT(*) AS frequency
    FROM gt_clientdata
    GROUP BY others
    ORDER BY frequency DESC
    LIMIT 1
) AS subquery;

--Second Moment Business Decision/Measures of Dispersion
--Variance
SELECT VARIANCE(others) AS others_variance
FROM gt_clientdata;

--Standard Deviation 
SELECT STDDEV(others) AS others_stddev
FROM gt_clientdata;

# Range
SELECT MAX(others) - MIN(others) AS others_range
FROM gt_clientdata;


--Third and Fourth Moment Business Decision
-- skewness and kurkosis 

SELECT
    (
        SUM(POWER(others - (SELECT AVG(others) FROM gt_clientdata), 3)) / 
        (COUNT(*) * POWER((SELECT STDDEV(others) FROM gt_clientdata), 3))
    ) AS skewness,
    (
        (SUM(POWER(others - (SELECT AVG(others) FROM gt_clientdata), 4)) / 
        (COUNT(*) * POWER((SELECT STDDEV(others) FROM gt_clientdata), 4))) - 3
    ) AS kurtosis
FROM gt_clientdata

select * from gt_clientdata
---------------------------------------------------------------------------
-- First Moment Business Decision 
-- scrap_qty_mt Mean 
SELECT AVG(scrap_qty_mt) AS mean_scrap_qty_mt
FROM gt_clientdata;

--MEDIAN
SELECT scrap_qty_mt AS median_scrap_qty_mt
FROM (SELECT scrap_qty_mt, ROW_NUMBER() OVER (ORDER BY scrap_qty_mt) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM gt_clientdata
) AS subquery
WHERE row_num = (total_count + 1) / 2 OR row_num = (total_count + 2) / 2;  

--mode
 SELECT scrap_qty_mt AS mode_scrap_qty_mt
FROM (
    SELECT scrap_qty_mt, COUNT(*) AS frequency
    FROM gt_clientdata
    GROUP BY scrap_qty_mt
    ORDER BY frequency DESC
    LIMIT 1
) AS subquery;

--Second Moment Business Decision/Measures of Dispersion
--Variance
SELECT VARIANCE(scrap_qty_mt) AS scrap_qty_mt_variance
FROM gt_clientdata;

--Standard Deviation 
SELECT STDDEV(scrap_qty_mt) AS scrap_qty_mt_stddev
FROM gt_clientdata;

# Range
SELECT MAX(scrap_qty_mt) - MIN(scrap_qty_mt) AS scrap_qty_mt_range
FROM gt_clientdata;


--Third and Fourth Moment Business Decision
-- skewness and kurkosis 

SELECT
    (
        SUM(POWER(scrap_qty_mt - (SELECT AVG(scrap_qty_mt) FROM gt_clientdata), 3)) / 
        (COUNT(*) * POWER((SELECT STDDEV(scrap_qty_mt) FROM gt_clientdata), 3))
    ) AS skewness,
    (
        (SUM(POWER(scrap_qty_mt - (SELECT AVG(scrap_qty_mt) FROM gt_clientdata), 4)) / 
        (COUNT(*) * POWER((SELECT STDDEV(scrap_qty_mt) FROM gt_clientdata), 4))) - 3
    ) AS kurtosis
FROM gt_clientdata

-----------------------------------------------------------------------------------------

---------------------------------------------------------------------------
-- First Moment Business Decision 
-- pigiron Mean 
SELECT AVG(pigiron) AS mean_pigiron
FROM gt_clientdata;

--MEDIAN
SELECT pigiron AS median_pigiron
FROM (SELECT pigiron, ROW_NUMBER() OVER (ORDER BY pigiron) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM gt_clientdata
) AS subquery
WHERE row_num = (total_count + 1) / 2 OR row_num = (total_count + 2) / 2;  

--mode
 SELECT pigiron AS mode_pigiron
FROM (
    SELECT pigiron, COUNT(*) AS frequency
    FROM gt_clientdata
    GROUP BY pigiron
    ORDER BY frequency DESC
    LIMIT 1
) AS subquery;

--Second Moment Business Decision/Measures of Dispersion
--Variance
SELECT VARIANCE(pigiron) AS pigiron_mt_variance
FROM gt_clientdata;

--Standard Deviation 
SELECT STDDEV(pigiron) AS pigiron_stddev
FROM gt_clientdata;

# Range
SELECT MAX(pigiron) - MIN(pigiron) AS pigiron_range
FROM gt_clientdata;


--Third and Fourth Moment Business Decision
-- skewness and kurkosis 

SELECT
    (
        SUM(POWER(pigiron - (SELECT AVG(pigiron) FROM gt_clientdata), 3)) / 
        (COUNT(*) * POWER((SELECT STDDEV(pigiron) FROM gt_clientdata), 3))
    ) AS skewness,
    (
        (SUM(POWER(pigiron - (SELECT AVG(pigiron) FROM gt_clientdata), 4)) / 
        (COUNT(*) * POWER((SELECT STDDEV(pigiron) FROM gt_clientdata), 4))) - 3
    ) AS kurtosis
FROM gt_clientdata

------------------------------------------------------------------------------------------
-- First Moment Business Decision 
-- dri1_qty_mt_lumps Mean 
SELECT AVG(dri1_qty_mt_lumps) AS mean_dri1_qty_mt_lumps
FROM gt_clientdata;

--MEDIAN
SELECT dri1_qty_mt_lumps AS median_dri1_qty_mt_lumps
FROM (SELECT dri1_qty_mt_lumps, ROW_NUMBER() OVER (ORDER BY dri1_qty_mt_lumps) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM gt_clientdata
) AS subquery
WHERE row_num = (total_count + 1) / 2 OR row_num = (total_count + 2) / 2;  

--mode
 SELECT dri1_qty_mt_lumps AS mode_dri1_qty_mt_lumps
FROM (
    SELECT dri1_qty_mt_lumps, COUNT(*) AS frequency
    FROM gt_clientdata
    GROUP BY dri1_qty_mt_lumps
    ORDER BY frequency DESC
    LIMIT 1
) AS subquery;

--Second Moment Business Decision/Measures of Dispersion
--Variance
SELECT VARIANCE(dri1_qty_mt_lumps) AS dri1_qty_mt_lumps_variance
FROM gt_clientdata;

--Standard Deviation 
SELECT STDDEV(dri1_qty_mt_lumps) AS dri1_qty_mt_lumps_stddev
FROM gt_clientdata;

# Range
SELECT MAX(dri1_qty_mt_lumps) - MIN(dri1_qty_mt_lumps) AS dri1_qty_mt_lumps_range
FROM gt_clientdata;


--Third and Fourth Moment Business Decision
-- skewness and kurkosis 

SELECT
    (
        SUM(POWER(dri1_qty_mt_lumps - (SELECT AVG(dri1_qty_mt_lumps) FROM gt_clientdata), 3)) / 
        (COUNT(*) * POWER((SELECT STDDEV(dri1_qty_mt_lumps) FROM gt_clientdata), 3))
    ) AS skewness,
    (
        (SUM(POWER(dri1_qty_mt_lumps - (SELECT AVG(dri1_qty_mt_lumps) FROM gt_clientdata), 4)) / 
        (COUNT(*) * POWER((SELECT STDDEV(dri1_qty_mt_lumps) FROM gt_clientdata), 4))) - 3
    ) AS kurtosis
FROM gt_clientdata

------------------------------------------------------------------------------------------

select * from gt_clientdata

-- First Moment Business Decision 
-- dri2_qty_mt_fines Mean 
SELECT AVG(dri2_qty_mt_fines) AS mean_dri2_qty_mt_fines
FROM gt_clientdata;

--MEDIAN
SELECT dri2_qty_mt_fines AS median_dri2_qty_mt_fines
FROM (SELECT dri2_qty_mt_fines, ROW_NUMBER() OVER (ORDER BY dri2_qty_mt_fines) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM gt_clientdata
) AS subquery
WHERE row_num = (total_count + 1) / 2 OR row_num = (total_count + 2) / 2;  

--mode
 SELECT dri2_qty_mt_fines AS mode_dri2_qty_mt_fines
FROM (
    SELECT dri2_qty_mt_fines, COUNT(*) AS frequency
    FROM gt_clientdata
    GROUP BY dri2_qty_mt_fines
    ORDER BY frequency DESC
    LIMIT 1
) AS subquery;

--Second Moment Business Decision/Measures of Dispersion
--Variance
SELECT VARIANCE(dri2_qty_mt_fines) AS dri2_qty_mt_fines_variance
FROM gt_clientdata;

--Standard Deviation 
SELECT STDDEV(dri2_qty_mt_fines) AS dri2_qty_mt_fines_stddev
FROM gt_clientdata;

# Range
SELECT MAX(dri2_qty_mt_fines) - MIN(dri2_qty_mt_fines) AS dri2_qty_mt_fines_range
FROM gt_clientdata;


--Third and Fourth Moment Business Decision
-- skewness and kurkosis 

SELECT
    (
        SUM(POWER(dri2_qty_mt_fines - (SELECT AVG(dri2_qty_mt_fines) FROM gt_clientdata), 3)) / 
        (COUNT(*) * POWER((SELECT STDDEV(dri2_qty_mt_fines) FROM gt_clientdata), 3))
    ) AS skewness,
    (
        (SUM(POWER(dri2_qty_mt_fines - (SELECT AVG(dri2_qty_mt_fines) FROM gt_clientdata), 4)) / 
        (COUNT(*) * POWER((SELECT STDDEV(dri2_qty_mt_fines) FROM gt_clientdata), 4))) - 3
    ) AS kurtosis
FROM gt_clientdata

------------------------------------------------------------------------------------------

select * from gt_clientdata


-- First Moment Business Decision 
-- tot_dri_qty Mean 
SELECT AVG(tot_dri_qty) AS mean_tot_dri_qty
FROM gt_clientdata;

--MEDIAN
SELECT tot_dri_qty AS median_tot_dri_qty
FROM (SELECT tot_dri_qty, ROW_NUMBER() OVER (ORDER BY tot_dri_qty) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM gt_clientdata
) AS subquery
WHERE row_num = (total_count + 1) / 2 OR row_num = (total_count + 2) / 2;  

--mode
 SELECT tot_dri_qty AS mode_tot_dri_qty
FROM (
    SELECT tot_dri_qty, COUNT(*) AS frequency
    FROM gt_clientdata
    GROUP BY tot_dri_qty
    ORDER BY frequency DESC
    LIMIT 1
) AS subquery;

--Second Moment Business Decision/Measures of Dispersion
--Variance
SELECT VARIANCE(tot_dri_qty) AS tot_dri_qty_variance
FROM gt_clientdata;

--Standard Deviation 
SELECT STDDEV(tot_dri_qty) AS tot_dri_qty_stddev
FROM gt_clientdata;

# Range
SELECT MAX(tot_dri_qty) - MIN(tot_dri_qty) AS tot_dri_qty_range
FROM gt_clientdata;


--Third and Fourth Moment Business Decision
-- skewness and kurkosis 

SELECT
    (
        SUM(POWER(tot_dri_qty - (SELECT AVG(tot_dri_qty) FROM gt_clientdata), 3)) / 
        (COUNT(*) * POWER((SELECT STDDEV(tot_dri_qty) FROM gt_clientdata), 3))
    ) AS skewness,
    (
        (SUM(POWER(tot_dri_qty - (SELECT AVG(tot_dri_qty) FROM gt_clientdata), 4)) / 
        (COUNT(*) * POWER((SELECT STDDEV(tot_dri_qty) FROM gt_clientdata), 4))) - 3
    ) AS kurtosis
FROM gt_clientdata

------------------------------------------------------------------------------------------
select * from gt_clientdata


-- First Moment Business Decision 
-- hot_metal_from_mbf Mean 
SELECT AVG(hot_metal_from_mbf) AS mean_hot_metal_from_mbf
FROM gt_clientdata;

--MEDIAN
SELECT hot_metal_from_mbf AS median_hot_metal_from_mbf
FROM (SELECT hot_metal_from_mbf, ROW_NUMBER() OVER (ORDER BY hot_metal_from_mbf) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM gt_clientdata
) AS subquery
WHERE row_num = (total_count + 1) / 2 OR row_num = (total_count + 2) / 2;  

--mode
 SELECT hot_metal_from_mbf AS mode_hot_metal_from_mbf
FROM (
    SELECT hot_metal_from_mbf, COUNT(*) AS frequency
    FROM gt_clientdata
    GROUP BY hot_metal_from_mbf
    ORDER BY frequency DESC
    LIMIT 1
) AS subquery;

--Second Moment Business Decision/Measures of Dispersion
--Variance
SELECT VARIANCE(hot_metal_from_mbf) AS hot_metal_from_mbf_variance
FROM gt_clientdata;

--Standard Deviation 
SELECT STDDEV(hot_metal_from_mbf) AS hot_metal_from_mbf_stddev
FROM gt_clientdata;

# Range
SELECT MAX(hot_metal_from_mbf) - MIN(hot_metal_from_mbf) AS hot_metal_from_mbf_range
FROM gt_clientdata;


--Third and Fourth Moment Business Decision
-- skewness and kurkosis 

SELECT
    (
        SUM(POWER(hot_metal_from_mbf - (SELECT AVG(hot_metal_from_mbf) FROM gt_clientdata), 3)) / 
        (COUNT(*) * POWER((SELECT STDDEV(hot_metal_from_mbf) FROM gt_clientdata), 3))
    ) AS skewness,
    (
        (SUM(POWER(hot_metal_from_mbf - (SELECT AVG(hot_metal_from_mbf) FROM gt_clientdata), 4)) / 
        (COUNT(*) * POWER((SELECT STDDEV(hot_metal_from_mbf) FROM gt_clientdata), 4))) - 3
    ) AS kurtosis
FROM gt_clientdata

------------------------------------------------------------------------------------------

select * from gt_clientdata


-- First Moment Business Decision 
-- total_charge Mean 
SELECT AVG(total_charge) AS mean_total_charge
FROM gt_clientdata;

--MEDIAN
SELECT total_charge AS median_total_charge
FROM (SELECT total_charge, ROW_NUMBER() OVER (ORDER BY total_charge) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM gt_clientdata
) AS subquery
WHERE row_num = (total_count + 1) / 2 OR row_num = (total_count + 2) / 2;  

--mode
 SELECT total_charge AS mode_total_charge
FROM (
    SELECT total_charge, COUNT(*) AS frequency
    FROM gt_clientdata
    GROUP BY total_charge
    ORDER BY frequency DESC
    LIMIT 1
) AS subquery;

--Second Moment Business Decision/Measures of Dispersion
--Variance
SELECT VARIANCE(total_charge) AS total_charge_variance
FROM gt_clientdata;

--Standard Deviation 
SELECT STDDEV(total_charge) AS total_charge_stddev
FROM gt_clientdata;

# Range
SELECT MAX(total_charge) - MIN(total_charge) AS total_charge_range
FROM gt_clientdata;


--Third and Fourth Moment Business Decision
-- skewness and kurkosis 

SELECT
    (
        SUM(POWER(total_charge - (SELECT AVG(total_charge) FROM gt_clientdata), 3)) / 
        (COUNT(*) * POWER((SELECT STDDEV(total_charge) FROM gt_clientdata), 3))
    ) AS skewness,
    (
        (SUM(POWER(total_charge - (SELECT AVG(total_charge) FROM gt_clientdata), 4)) / 
        (COUNT(*) * POWER((SELECT STDDEV(total_charge) FROM gt_clientdata), 4))) - 3
    ) AS kurtosis
FROM gt_clientdata

------------------------------------------------------------------------------------------
select * from gt_clientdata


-- First Moment Business Decision 
-- dolo Mean 
SELECT AVG(dolo) AS mean_dolo
FROM gt_clientdata;

--MEDIAN
SELECT dolo AS median_dolo
FROM (SELECT dolo, ROW_NUMBER() OVER (ORDER BY dolo) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM gt_clientdata
) AS subquery
WHERE row_num = (total_count + 1) / 2 OR row_num = (total_count + 2) / 2;  

--mode
 SELECT dolo AS mode_dolo
FROM (
    SELECT dolo, COUNT(*) AS frequency
    FROM gt_clientdata
    GROUP BY dolo
    ORDER BY frequency DESC
    LIMIT 1
) AS subquery;

--Second Moment Business Decision/Measures of Dispersion
--Variance
SELECT VARIANCE(dolo) AS dolo_variance
FROM gt_clientdata;

--Standard Deviation 
SELECT STDDEV(dolo) AS dolo_stddev
FROM gt_clientdata;

# Range
SELECT MAX(dolo) - MIN(dolo) AS dolo_range
FROM gt_clientdata;


--Third and Fourth Moment Business Decision
-- skewness and kurkosis 

SELECT
    (
        SUM(POWER(dolo - (SELECT AVG(dolo) FROM gt_clientdata), 3)) / 
        (COUNT(*) * POWER((SELECT STDDEV(dolo) FROM gt_clientdata), 3))
    ) AS skewness,
    (
        (SUM(POWER(dolo - (SELECT AVG(dolo) FROM gt_clientdata), 4)) / 
        (COUNT(*) * POWER((SELECT STDDEV(dolo) FROM gt_clientdata), 4))) - 3
    ) AS kurtosis
FROM gt_clientdata


------------------------------------------------------------------------------------------
select * from gt_clientdata


-- First Moment Business Decision 
-- dolo1_empty Mean 
SELECT AVG(dolo1_empty) AS mean_dolo1_empty
FROM gt_clientdata;

--MEDIAN
SELECT dolo1_empty AS median_dolo1_empty
FROM (SELECT dolo1_empty, ROW_NUMBER() OVER (ORDER BY dolo1_empty) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM gt_clientdata
) AS subquery
WHERE row_num = (total_count + 1) / 2 OR row_num = (total_count + 2) / 2;  

--mode
 SELECT dolo1_empty AS mode_dolo1_empty
FROM (
    SELECT dolo1_empty, COUNT(*) AS frequency
    FROM gt_clientdata
    GROUP BY dolo1_empty
    ORDER BY frequency DESC
    LIMIT 1
) AS subquery;

--Second Moment Business Decision/Measures of Dispersion
--Variance
SELECT VARIANCE(dolo1_empty) AS dolo1_empty_variance
FROM gt_clientdata;

--Standard Deviation 
SELECT STDDEV(dolo1_empty) AS dolo1_empty_stddev
FROM gt_clientdata;

# Range
SELECT MAX(dolo1_empty) - MIN(dolo1_empty) AS dolo1_empty_range
FROM gt_clientdata;


--Third and Fourth Moment Business Decision
-- skewness and kurkosis 

SELECT
    (
        SUM(POWER(dolo1_empty - (SELECT AVG(dolo1_empty) FROM gt_clientdata), 3)) / 
        (COUNT(*) * POWER((SELECT STDDEV(dolo1_empty) FROM gt_clientdata), 3))
    ) AS skewness,
    (
        (SUM(POWER(dolo1_empty - (SELECT AVG(dolo1_empty) FROM gt_clientdata), 4)) / 
        (COUNT(*) * POWER((SELECT STDDEV(dolo1_empty) FROM gt_clientdata), 4))) - 3
    ) AS kurtosis
FROM gt_clientdata

------------------------------------------------------------------------------------------
select * from gt_clientdata


-- First Moment Business Decision 
-- tot_lime_qty Mean 
SELECT AVG(tot_lime_qty) AS mean_tot_lime_qty
FROM gt_clientdata;

--MEDIAN
SELECT tot_lime_qty AS median_tot_lime_qty
FROM (SELECT tot_lime_qty, ROW_NUMBER() OVER (ORDER BY tot_lime_qty) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM gt_clientdata
) AS subquery
WHERE row_num = (total_count + 1) / 2 OR row_num = (total_count + 2) / 2;  

--mode
 SELECT tot_lime_qty AS mode_tot_lime_qty
FROM (
    SELECT tot_lime_qty, COUNT(*) AS frequency
    FROM gt_clientdata
    GROUP BY tot_lime_qty
    ORDER BY frequency DESC
    LIMIT 1
) AS subquery;

--Second Moment Business Decision/Measures of Dispersion
--Variance
SELECT VARIANCE(tot_lime_qty) AS tot_lime_qty_variance
FROM gt_clientdata;

--Standard Deviation 
SELECT STDDEV(tot_lime_qty) AS tot_lime_qty_stddev
FROM gt_clientdata;

# Range
SELECT MAX(tot_lime_qty) - MIN(tot_lime_qty) AS tot_lime_qty_range
FROM gt_clientdata;


--Third and Fourth Moment Business Decision
-- skewness and kurkosis 

SELECT
    (
        SUM(POWER(tot_lime_qty - (SELECT AVG(tot_lime_qty) FROM gt_clientdata), 3)) / 
        (COUNT(*) * POWER((SELECT STDDEV(tot_lime_qty) FROM gt_clientdata), 3))
    ) AS skewness,
    (
        (SUM(POWER(tot_lime_qty - (SELECT AVG(tot_lime_qty) FROM gt_clientdata), 4)) / 
        (COUNT(*) * POWER((SELECT STDDEV(tot_lime_qty) FROM gt_clientdata), 4))) - 3
    ) AS kurtosis
FROM gt_clientdata

------------------------------------------------------------------------------------------
select * from gt_clientdata


-- First Moment Business Decision 
-- tap_temp Mean 
SELECT AVG(tap_temp) AS mean_tap_temp
FROM gt_clientdata;

--MEDIAN
SELECT tap_temp AS median_tap_temp
FROM (SELECT tap_temp, ROW_NUMBER() OVER (ORDER BY tap_temp) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM gt_clientdata
) AS subquery
WHERE row_num = (total_count + 1) / 2 OR row_num = (total_count + 2) / 2;  

--mode
 SELECT tap_temp AS mode_tap_temp
FROM (
    SELECT tap_temp, COUNT(*) AS frequency
    FROM gt_clientdata
    GROUP BY tap_temp
    ORDER BY frequency DESC
    LIMIT 1
) AS subquery;

--Second Moment Business Decision/Measures of Dispersion
--Variance
SELECT VARIANCE(tap_temp) AS tap_temp_variance
FROM gt_clientdata;

--Standard Deviation 
SELECT STDDEV(tap_temp) AS tap_temp_stddev
FROM gt_clientdata;

# Range
SELECT MAX(tap_temp) - MIN(tap_temp) AS tap_temp_range
FROM gt_clientdata;


--Third and Fourth Moment Business Decision
-- skewness and kurkosis 

SELECT
    (
        SUM(POWER(tap_temp - (SELECT AVG(tap_temp) FROM gt_clientdata), 3)) / 
        (COUNT(*) * POWER((SELECT STDDEV(tap_temp) FROM gt_clientdata), 3))
    ) AS skewness,
    (
        (SUM(POWER(tap_temp - (SELECT AVG(tap_temp) FROM gt_clientdata), 4)) / 
        (COUNT(*) * POWER((SELECT STDDEV(tap_temp) FROM gt_clientdata), 4))) - 3
    ) AS kurtosis
FROM gt_clientdata

------------------------------------------------------------------------------------------
select * from gt_clientdata


-- First Moment Business Decision 
-- o2act Mean 
SELECT AVG(o2act) AS mean_o2act
FROM gt_clientdata;

--MEDIAN
SELECT o2act AS median_o2act
FROM (SELECT o2act, ROW_NUMBER() OVER (ORDER BY o2act) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM gt_clientdata
) AS subquery
WHERE row_num = (total_count + 1) / 2 OR row_num = (total_count + 2) / 2;  

--mode
 SELECT o2act AS mode_o2act
FROM (
    SELECT o2act, COUNT(*) AS frequency
    FROM gt_clientdata
    GROUP BY o2act
    ORDER BY frequency DESC
    LIMIT 1
) AS subquery;

--Second Moment Business Decision/Measures of Dispersion
--Variance
SELECT VARIANCE(o2act) AS o2act_variance
FROM gt_clientdata;

--Standard Deviation 
SELECT STDDEV(o2act) AS o2act_stddev
FROM gt_clientdata;

# Range
SELECT MAX(o2act) - MIN(o2act) AS o2act_range
FROM gt_clientdata;


--Third and Fourth Moment Business Decision
-- skewness and kurkosis 

SELECT
    (
        SUM(POWER(o2act - (SELECT AVG(o2act) FROM gt_clientdata), 3)) / 
        (COUNT(*) * POWER((SELECT STDDEV(o2act) FROM gt_clientdata), 3))
    ) AS skewness,
    (
        (SUM(POWER(o2act - (SELECT AVG(o2act) FROM gt_clientdata), 4)) / 
        (COUNT(*) * POWER((SELECT STDDEV(o2act) FROM gt_clientdata), 4))) - 3
    ) AS kurtosis
FROM gt_clientdata

------------------------------------------------------------------------------------------
select * from gt_clientdata


-- First Moment Business Decision 
-- energy Mean 
SELECT AVG(energy) AS mean_energy
FROM gt_clientdata;

--MEDIAN
SELECT energy AS median_energy
FROM (SELECT energy, ROW_NUMBER() OVER (ORDER BY energy) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM gt_clientdata
) AS subquery
WHERE row_num = (total_count + 1) / 2 OR row_num = (total_count + 2) / 2;  

--mode
 SELECT energy AS mode_energy
FROM (
    SELECT energy, COUNT(*) AS frequency
    FROM gt_clientdata
    GROUP BY energy
    ORDER BY frequency DESC
    LIMIT 1
) AS subquery;

--Second Moment Business Decision/Measures of Dispersion
--Variance
SELECT VARIANCE(energy) AS energy_variance
FROM gt_clientdata;

--Standard Deviation 
SELECT STDDEV(energy) energy_stddev
FROM gt_clientdata;

# Range
SELECT MAX(energy) - MIN(energy) AS energy_range
FROM gt_clientdata;


--Third and Fourth Moment Business Decision
-- skewness and kurkosis 

SELECT
    (
        SUM(POWER(energy - (SELECT AVG(energy) FROM gt_clientdata), 3)) / 
        (COUNT(*) * POWER((SELECT STDDEV(energy) FROM gt_clientdata), 3))
    ) AS skewness,
    (
        (SUM(POWER(energy - (SELECT AVG(energy) FROM gt_clientdata), 4)) / 
        (COUNT(*) * POWER((SELECT STDDEV(energy) FROM gt_clientdata), 4))) - 3
    ) AS kurtosis
FROM gt_clientdata
------------------------------------------------------------------------------------------
select * from gt_clientdata


-- First Moment Business Decision 
-- kwh_per_ton Mean 
SELECT AVG(kwh_per_ton) AS mean_kwh_per_ton
FROM gt_clientdata;

--MEDIAN
SELECT kwh_per_ton AS median_kwh_per_ton
FROM (SELECT kwh_per_ton, ROW_NUMBER() OVER (ORDER BY kwh_per_ton) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM gt_clientdata
) AS subquery
WHERE row_num = (total_count + 1) / 2 OR row_num = (total_count + 2) / 2;  

--mode
 SELECT kwh_per_ton AS mode_kwh_per_ton
FROM (
    SELECT kwh_per_ton, COUNT(*) AS frequency
    FROM gt_clientdata
    GROUP BY kwh_per_ton
    ORDER BY frequency DESC
    LIMIT 1
) AS subquery;

--Second Moment Business Decision/Measures of Dispersion
--Variance
SELECT VARIANCE(kwh_per_ton) AS kwh_per_ton_variance
FROM gt_clientdata;

--Standard Deviation 
SELECT STDDEV(kwh_per_ton) kwh_per_ton_stddev
FROM gt_clientdata;

# Range
SELECT MAX(kwh_per_ton) - MIN(kwh_per_ton) AS kwh_per_ton_range
FROM gt_clientdata;


--Third and Fourth Moment Business Decision
-- skewness and kurkosis 

SELECT
    (
        SUM(POWER(kwh_per_ton - (SELECT AVG(kwh_per_ton) FROM gt_clientdata), 3)) / 
        (COUNT(*) * POWER((SELECT STDDEV(kwh_per_ton) FROM gt_clientdata), 3))
    ) AS skewness,
    (
        (SUM(POWER(kwh_per_ton - (SELECT AVG(kwh_per_ton) FROM gt_clientdata), 4)) / 
        (COUNT(*) * POWER((SELECT STDDEV(kwh_per_ton) FROM gt_clientdata), 4))) - 3
    ) AS kurtosis
FROM gt_clientdata

------------------------------------------------------------------------------------------
select * from gt_clientdata


-- First Moment Business Decision 
-- kwh_per_min Mean 
SELECT AVG(kwh_per_min) AS mean_kwh_per_min
FROM gt_clientdata;

--MEDIAN
SELECT kwh_per_min AS median_kwh_per_min
FROM (SELECT kwh_per_min, ROW_NUMBER() OVER (ORDER BY kwh_per_min) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM gt_clientdata
) AS subquery
WHERE row_num = (total_count + 1) / 2 OR row_num = (total_count + 2) / 2;  

--mode
 SELECT kwh_per_min AS mode_kwh_per_min
FROM (
    SELECT kwh_per_min, COUNT(*) AS frequency
    FROM gt_clientdata
    GROUP BY kwh_per_min
    ORDER BY frequency DESC
    LIMIT 1
) AS subquery;

--Second Moment Business Decision/Measures of Dispersion
--Variance
SELECT VARIANCE(kwh_per_min) AS kwh_per_min_variance
FROM gt_clientdata;

--Standard Deviation 
SELECT STDDEV(kwh_per_min) kwh_per_min_stddev
FROM gt_clientdata;

# Range
SELECT MAX(kwh_per_min) - MIN(kwh_per_min) AS kwh_per_min_range
FROM gt_clientdata;


--Third and Fourth Moment Business Decision
-- skewness and kurkosis 

SELECT
    (
        SUM(POWER(kwh_per_min - (SELECT AVG(kwh_per_min) FROM gt_clientdata), 3)) / 
        (COUNT(*) * POWER((SELECT STDDEV(kwh_per_min) FROM gt_clientdata), 3))
    ) AS skewness,
    (
        (SUM(POWER(kwh_per_min - (SELECT AVG(kwh_per_min) FROM gt_clientdata), 4)) / 
        (COUNT(*) * POWER((SELECT STDDEV(kwh_per_min) FROM gt_clientdata), 4))) - 3
    ) AS kurtosis
FROM gt_clientdata
------------------------------------------------------------------------------------------
select * from gt_clientdata


-- First Moment Business Decision 
-- melt_time Mean 
SELECT AVG(melt_time) AS mean_melt_time
FROM gt_clientdata;

--MEDIAN
SELECT melt_time AS median_melt_time
FROM (SELECT melt_time, ROW_NUMBER() OVER (ORDER BY melt_time) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM gt_clientdata
) AS subquery
WHERE row_num = (total_count + 1) / 2 OR row_num = (total_count + 2) / 2;  

--mode
 SELECT melt_time AS mode_melt_time
FROM (
    SELECT melt_time, COUNT(*) AS frequency
    FROM gt_clientdata
    GROUP BY melt_time
    ORDER BY frequency DESC
    LIMIT 1
) AS subquery;

--Second Moment Business Decision/Measures of Dispersion
--Variance
SELECT VARIANCE(melt_time) AS melt_time_variance
FROM gt_clientdata;

--Standard Deviation 
SELECT STDDEV(melt_time) melt_time_stddev
FROM gt_clientdata;

# Range
SELECT MAX(melt_time) - MIN(melt_time) AS melt_time_range
FROM gt_clientdata;


--Third and Fourth Moment Business Decision
-- skewness and kurkosis 

SELECT
    (
        SUM(POWER(melt_time - (SELECT AVG(melt_time) FROM gt_clientdata), 3)) / 
        (COUNT(*) * POWER((SELECT STDDEV(melt_time) FROM gt_clientdata), 3))
    ) AS skewness,
    (
        (SUM(POWER(melt_time - (SELECT AVG(melt_time) FROM gt_clientdata), 4)) / 
        (COUNT(*) * POWER((SELECT STDDEV(melt_time) FROM gt_clientdata), 4))) - 3
    ) AS kurtosis
FROM gt_clientdata
------------------------------------------------------------------------------------------
select * from gt_clientdata


-- First Moment Business Decision 
-- ta_time Mean 
SELECT AVG(ta_time) AS mean_ta_time
FROM gt_clientdata;

--MEDIAN
SELECT ta_time AS median_ta_time
FROM (SELECT ta_time, ROW_NUMBER() OVER (ORDER BY ta_time) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM gt_clientdata
) AS subquery
WHERE row_num = (total_count + 1) / 2 OR row_num = (total_count + 2) / 2;  

--mode
 SELECT ta_time AS mode_ta_time
FROM (
    SELECT ta_time, COUNT(*) AS frequency
    FROM gt_clientdata
    GROUP BY ta_time
    ORDER BY frequency DESC
    LIMIT 1
) AS subquery;

--Second Moment Business Decision/Measures of Dispersion
--Variance
SELECT VARIANCE(ta_time) AS ta_time_variance
FROM gt_clientdata;

--Standard Deviation 
SELECT STDDEV(ta_time) ta_time_stddev
FROM gt_clientdata;

# Range
SELECT MAX(ta_time) - MIN(ta_time) AS ta_time_range
FROM gt_clientdata;


--Third and Fourth Moment Business Decision
-- skewness and kurkosis 

SELECT
    (
        SUM(POWER(ta_time - (SELECT AVG(ta_time) FROM gt_clientdata), 3)) / 
        (COUNT(*) * POWER((SELECT STDDEV(ta_time) FROM gt_clientdata), 3))
    ) AS skewness,
    (
        (SUM(POWER(ta_time - (SELECT AVG(ta_time) FROM gt_clientdata), 4)) / 
        (COUNT(*) * POWER((SELECT STDDEV(ta_time) FROM gt_clientdata), 4))) - 3
    ) AS kurtosis
FROM gt_clientdata

------------------------------------------------------------------------------------------
select * from gt_clientdata


-- First Moment Business Decision 
-- tt_time Mean 
SELECT AVG(tt_time) AS mean_tt_time
FROM gt_clientdata;

--MEDIAN
SELECT tt_time AS median_tt_time
FROM (SELECT tt_time, ROW_NUMBER() OVER (ORDER BY tt_time) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM gt_clientdata
) AS subquery
WHERE row_num = (total_count + 1) / 2 OR row_num = (total_count + 2) / 2;  

--mode
 SELECT tt_time AS mode_tt_time
FROM (
    SELECT tt_time, COUNT(*) AS frequency
    FROM gt_clientdata
    GROUP BY tt_time
    ORDER BY frequency DESC
    LIMIT 1
) AS subquery;

--Second Moment Business Decision/Measures of Dispersion
--Variance
SELECT VARIANCE(tt_time) AS tt_time_variance
FROM gt_clientdata;

--Standard Deviation 
SELECT STDDEV(tt_time) tt_time_stddev
FROM gt_clientdata;

# Range
SELECT MAX(tt_time) - MIN(tt_time) AS tt_time_range
FROM gt_clientdata;


--Third and Fourth Moment Business Decision
-- skewness and kurkosis 

SELECT
    (
        SUM(POWER(tt_time - (SELECT AVG(tt_time) FROM gt_clientdata), 3)) / 
        (COUNT(*) * POWER((SELECT STDDEV(tt_time) FROM gt_clientdata), 3))
    ) AS skewness,
    (
        (SUM(POWER(tt_time - (SELECT AVG(tt_time) FROM gt_clientdata), 4)) / 
        (COUNT(*) * POWER((SELECT STDDEV(tt_time) FROM gt_clientdata), 4))) - 3
    ) AS kurtosis
FROM gt_clientdata
---------------------------------------------------------------------------------
--pow_on_time mode
 SELECT pow_on_time AS mode_pow_on_time
FROM (
    SELECT pow_on_time, COUNT(*) AS frequency
    FROM gt_clientdata
    GROUP BY pow_on_time
    ORDER BY frequency DESC
    LIMIT 1
) AS subquery;
--------------------------------------------------------------------------------------
--pow_on_time mode
 SELECT tapping_time AS mode_tapping_time
FROM (
    SELECT tapping_time, COUNT(*) AS frequency
    FROM gt_clientdata
    GROUP BY tapping_time
    ORDER BY frequency DESC
    LIMIT 1
) AS subquery;
---------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------
select * from gt_clientdata


-- First Moment Business Decision 
--e1_cur Mean 
SELECT AVG(e1_cur) AS mean_e1_cur
FROM gt_clientdata;

--MEDIAN
SELECT e1_cur AS median_e1_cur
FROM (SELECT e1_cur, ROW_NUMBER() OVER (ORDER BY e1_cur) AS row_num,
   
 SELECT e1_cur AS mode_e1_cur COUNT(*) OVER () AS total_count
    FROM gt_clientdata
) AS subquery
WHERE row_num = (total_count + 1) / 2 OR row_num = (total_count + 2) / 2;  

--modeECT e1_cur AS mode_e1_cur
FROM (
    SELECT e1_cur, COUNT(*) AS frequency
    FROM gt_clientdata
    GROUP BY e1_cur
    ORDER BY frequency DESC
    LIMIT 1
) AS subquery;

--Second Moment Business Decision/Measures of Dispersion
--Variance
SELECT VARIANCE(e1_cur) AS e1_cur_variance
FROM gt_clientdata;

--Standard Deviation 
SELECT STDDEV(e1_cur) e1_cur_stddev
FROM gt_clientdata;

# Range
SELECT MAX(e1_cur) - MIN(e1_cur) AS e1_cur_range
FROM gt_clientdata;


--Third and Fourth Moment Business Decision
-- skewness and kurkosis 

SELECT
    (
        SUM(POWER(e1_cur - (SELECT AVG(e1_cur) FROM gt_clientdata), 3)) / 
        (COUNT(*) * POWER((SELECT STDDEV(e1_cur) FROM gt_clientdata), 3))
    ) AS skewness,
    (
        (SUM(POWER(e1_cur - (SELECT AVG(e1_cur) FROM gt_clientdata), 4)) / 
        (COUNT(*) * POWER((SELECT STDDEV(e1_cur) FROM gt_clientdata), 4))) - 3
    ) AS kurtosis
FROM gt_clientdata

------------------------------------------------------------------------------------------
select * from gt_clientdata


-- First Moment Business Decision 
--e3_cur Mean 
SELECT AVG(e3_cur) AS mean_e3_cur
FROM gt_clientdata;

--MEDIAN
SELECT e3_cur AS median_e3_cur
FROM (SELECT e3_cur, ROW_NUMBER() OVER (ORDER BY e3_cur) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM gt_clientdata
) AS subquery
WHERE row_num = (total_count + 1) / 2 OR row_num = (total_count + 2) / 2;  

--mode
 SELECT e3_cur AS mode_e3_cur
FROM (
    SELECT e3_cur, COUNT(*) AS frequency
    FROM gt_clientdata
    GROUP BY e3_cur
    ORDER BY frequency DESC
    LIMIT 1
) AS subquery;

--Second Moment Business Decision/Measures of Dispersion
--Variance
SELECT VARIANCE(e3_cur) AS e3_cur_variance
FROM gt_clientdata;

--Standard Deviation 
SELECT STDDEV(e3_cur) AS e3_cur_stddev
FROM gt_clientdata;

# Range
SELECT MAX(e3_cur) - MIN(e3_cur) AS e3_cur_range
FROM gt_clientdata;


--Third and Fourth Moment Business Decision
-- skewness and kurkosis 

SELECT
    (
        SUM(POWER(e3_cur - (SELECT AVG(e3_cur) FROM gt_clientdata), 3)) / 
        (COUNT(*) * POWER((SELECT STDDEV(e3_cur) FROM gt_clientdata), 3))
    ) AS skewness,
    (
        (SUM(POWER(e3_cur - (SELECT AVG(e3_cur) FROM gt_clientdata), 4)) / 
        (COUNT(*) * POWER((SELECT STDDEV(e3_cur) FROM gt_clientdata), 4))) - 3
    ) AS kurtosis
FROM gt_clientdata

------------------------------------------------------------------------------------------
select * from gt_clientdata


-- First Moment Business Decision 
--spout Mean 
SELECT AVG(spout) AS mean_spout
FROM gt_clientdata;

--MEDIAN
SELECT spout AS median_spout
FROM (SELECT spout, ROW_NUMBER() OVER (ORDER BY spout) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM gt_clientdata
) AS subquery
WHERE row_num = (total_count + 1) / 2 OR row_num = (total_count + 2) / 2;  

--mode
 SELECT spout AS mode_spout
FROM (
    SELECT spout, COUNT(*) AS frequency
    FROM gt_clientdata
    GROUP BY spout
    ORDER BY frequency DESC
    LIMIT 1
) AS subquery;

--Second Moment Business Decision/Measures of Dispersion
--Variance
SELECT VARIANCE(spout) AS spout_variance
FROM gt_clientdata;

--Standard Deviation 
SELECT STDDEV(spout) AS spout_stddev
FROM gt_clientdata;

# Range
SELECT MAX(spout) - MIN(spout) AS spout_range
FROM gt_clientdata;


--Third and Fourth Moment Business Decision
-- skewness and kurkosis 

SELECT
    (
        SUM(POWER(spout - (SELECT AVG(spout) FROM gt_clientdata), 3)) / 
        (COUNT(*) * POWER((SELECT STDDEV(spout) FROM gt_clientdata), 3))
    ) AS skewness,
    (
        (SUM(POWER(spout - (SELECT AVG(spout) FROM gt_clientdata), 4)) / 
        (COUNT(*) * POWER((SELECT STDDEV(spout) FROM gt_clientdata), 4))) - 3
    ) AS kurtosis
FROM gt_clientdata

------------------------------------------------------------------------------------------
select * from gt_clientdata


-- First Moment Business Decision 
--lab_rep_time Mode
--mode
 SELECT lab_rep_time AS mode_lab_rep_time
FROM (
    SELECT lab_rep_time, COUNT(*) AS frequency
    FROM gt_clientdata
    GROUP BY lab_rep_time
    ORDER BY frequency DESC
    LIMIT 1
) AS subquery;

------------------------------------------------------------------------------------------

select * from gt_clientdata

-- First Moment Business Decision 
-- si Mean 
SELECT AVG(si) AS mean_si
FROM gt_clientdata;

--MEDIAN
SELECT si AS median_si
FROM (SELECT si, ROW_NUMBER() OVER (ORDER BY si) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM gt_clientdata
) AS subquery
WHERE row_num = (total_count + 1) / 2 OR row_num = (total_count + 2) / 2;  

--mode
 SELECT si AS mode_si
FROM (
    SELECT si, COUNT(*) AS frequency
    FROM gt_clientdata
    GROUP BY si
    ORDER BY frequency DESC
    LIMIT 1
) AS subquery;

--Second Moment Business Decision/Measures of Dispersion
--Variance
SELECT VARIANCE(si) AS si_variance
FROM gt_clientdata;

--Standard Deviation 
SELECT STDDEV(si) AS si_stddev
FROM gt_clientdata;

# Range
SELECT MAX(si) - MIN(si) AS si_range
FROM gt_clientdata;


--Third and Fourth Moment Business Decision
-- skewness and kurkosis 

SELECT
    (
        SUM(POWER(si - (SELECT AVG(si) FROM gt_clientdata), 3)) / 
        (COUNT(*) * POWER((SELECT STDDEV(si) FROM gt_clientdata), 3))
    ) AS skewness,
    (
        (SUM(POWER(si - (SELECT AVG(si) FROM gt_clientdata), 4)) / 
        (COUNT(*) * POWER((SELECT STDDEV(si) FROM gt_clientdata), 4))) - 3
    ) AS kurtosis
FROM gt_clientdata
------------------------------------------------------------------------------------------

select * from gt_clientdata

-- First Moment Business Decision 
-- p Mean 
SELECT AVG(p) AS mean_p
FROM gt_clientdata;

--MEDIAN
SELECT p AS median_p
FROM (SELECT p, ROW_NUMBER() OVER (ORDER BY p) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM gt_clientdata
) AS subquery
WHERE row_num = (total_count + 1) / 2 OR row_num = (total_count + 2) / 2;  

--mode
 SELECT p AS mode_p
FROM (
    SELECT p, COUNT(*) AS frequency
    FROM gt_clientdata
    GROUP BY p
    ORDER BY frequency DESC
    LIMIT 1
) AS subquery;

--Second Moment Business Decision/Measures of Dispersion
--Variance
SELECT VARIANCE(p) AS p_variance
FROM gt_clientdata;

--Standard Deviation 
SELECT STDDEV(p) AS p_stddev
FROM gt_clientdata;

# Range
SELECT MAX(p) - MIN(p) AS p_range
FROM gt_clientdata;


--Third and Fourth Moment Business Decision
-- skewness and kurkosis 

SELECT
    (
        SUM(POWER(p - (SELECT AVG(p) FROM gt_clientdata), 3)) / 
        (COUNT(*) * POWER((SELECT STDDEV(p) FROM gt_clientdata), 3))
    ) AS skewness,
    (
        (SUM(POWER(p - (SELECT AVG(p) FROM gt_clientdata), 4)) / 
        (COUNT(*) * POWER((SELECT STDDEV(p) FROM gt_clientdata), 4))) - 3
    ) AS kurtosis
FROM gt_clientdata
------------------------------------------------------------------------------------------

select * from gt_clientdata

-- First Moment Business Decision 
-- s Mean 
SELECT AVG(s) AS mean_s
FROM gt_clientdata;

--MEDIAN
SELECT s AS median_s
FROM (SELECT s, ROW_NUMBER() OVER (ORDER BY s) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM gt_clientdata
) AS subquery
WHERE row_num = (total_count + 1) / 2 OR row_num = (total_count + 2) / 2;  

--mode
 SELECT s AS mode_s
FROM (
    SELECT s, COUNT(*) AS frequency
    FROM gt_clientdata
    GROUP BY s
    ORDER BY frequency DESC
    LIMIT 1
) AS subquery;

--Second Moment Business Decision/Measures of Dispersion
--Variance
SELECT VARIANCE(s) AS s_variance
FROM gt_clientdata;

--Standard Deviation 
SELECT STDDEV(s) AS s_stddev
FROM gt_clientdata;

# Range
SELECT MAX(s) - MIN(s) AS s_range
FROM gt_clientdata;


--Third and Fourth Moment Business Decision
-- skewness and kurkosis 

SELECT
    (
        SUM(POWER(s - (SELECT AVG(s) FROM gt_clientdata), 3)) / 
        (COUNT(*) * POWER((SELECT STDDEV(s) FROM gt_clientdata), 3))
    ) AS skewness,
    (
        (SUM(POWER(s - (SELECT AVG(s) FROM gt_clientdata), 4)) / 
        (COUNT(*) * POWER((SELECT STDDEV(s) FROM gt_clientdata), 4))) - 3
    ) AS kurtosis
FROM gt_clientdata
------------------------------------------------------------------------------------------

select * from gt_clientdata

-- First Moment Business Decision 
-- ni Mean 
SELECT AVG(ni) AS mean_ni
FROM gt_clientdata;

--MEDIAN
SELECT ni AS median_ni
FROM (SELECT ni, ROW_NUMBER() OVER (ORDER BY ni) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM gt_clientdata
) AS subquery
WHERE row_num = (total_count + 1) / 2 OR row_num = (total_count + 2) / 2;  

--mode
 SELECT ni AS mode_ni
FROM (
    SELECT ni, COUNT(*) AS frequency
    FROM gt_clientdata
    GROUP BY ni
    ORDER BY frequency DESC
    LIMIT 1
) AS subquery;

--Second Moment Business Decision/Measures of Dispersion
--Variance
SELECT VARIANCE(ni) AS ni_variance
FROM gt_clientdata;

--Standard Deviation 
SELECT STDDEV(ni) AS ni_stddev
FROM gt_clientdata;

# Range
SELECT MAX(ni) - MIN(ni) AS ni_range
FROM gt_clientdata;


--Third and Fourth Moment Business Decision
-- skewness and kurkosis 

SELECT
    (
        SUM(POWER(ni - (SELECT AVG(ni) FROM gt_clientdata), 3)) / 
        (COUNT(*) * POWER((SELECT STDDEV(ni) FROM gt_clientdata), 3))
    ) AS skewness,
    (
        (SUM(POWER(ni - (SELECT AVG(ni) FROM gt_clientdata), 4)) / 
        (COUNT(*) * POWER((SELECT STDDEV(ni) FROM gt_clientdata), 4))) - 3
    ) AS kurtosis
FROM gt_clientdata

------------------------------------------------------------------------------------------

select * from gt_clientdata

-- First Moment Business Decision 
-- n Mean 
SELECT AVG(n) AS mean_n
FROM gt_clientdata;

--MEDIAN
SELECT n AS median_n
FROM (SELECT n, ROW_NUMBER() OVER (ORDER BY n) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM gt_clientdata
) AS subquery
WHERE row_num = (total_count + 1) / 2 OR row_num = (total_count + 2) / 2;  

--mode
 SELECT n AS mode_n
FROM (
    SELECT n, COUNT(*) AS frequency
    FROM gt_clientdata
    GROUP BY n
    ORDER BY frequency DESC
    LIMIT 1
) AS subquery;

--Second Moment Business Decision/Measures of Dispersion
--Variance
SELECT VARIANCE(n) AS n_variance
FROM gt_clientdata;

--Standard Deviation 
SELECT STDDEV(n) AS n_stddev
FROM gt_clientdata;

# Range
SELECT MAX(n) - MIN(n) AS ni_range
FROM gt_clientdata;


--Third and Fourth Moment Business Decision
-- skewness and kurkosis 

SELECT
    (
        SUM(POWER(n - (SELECT AVG(n) FROM gt_clientdata), 3)) / 
        (COUNT(*) * POWER((SELECT STDDEV(n) FROM gt_clientdata), 3))
    ) AS skewness,
    (
        (SUM(POWER(n - (SELECT AVG(n) FROM gt_clientdata), 4)) / 
        (COUNT(*) * POWER((SELECT STDDEV(n) FROM gt_clientdata), 4))) - 3
    ) AS kurtosis
FROM gt_clientdata
------------------------------------------------------------------------------------------

select * from gt_clientdata

-- First Moment Business Decision 
-- tap_c Mean 
SELECT AVG(tap_c) AS mean_tap_c
FROM gt_clientdata;

--MEDIAN
SELECT tap_c AS median_tap_c
FROM (SELECT tap_c, ROW_NUMBER() OVER (ORDER BY tap_c) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM gt_clientdata
) AS subquery
WHERE row_num = (total_count + 1) / 2 OR row_num = (total_count + 2) / 2;  

--mode
 SELECT tap_c AS mode_tap_c
FROM (
    SELECT tap_c, COUNT(*) AS frequency
    FROM gt_clientdata
    GROUP BY tap_c
    ORDER BY frequency DESC
    LIMIT 1
) AS subquery;

--Second Moment Business Decision/Measures of Dispersion
--Variance
SELECT VARIANCE(tap_c) AS tap_c_variance
FROM gt_clientdata;

--Standard Deviation 
SELECT STDDEV(tap_c) AS tap_c_stddev
FROM gt_clientdata;

# Range
SELECT MAX(tap_c) - MIN(tap_c) AS tap_c_range
FROM gt_clientdata;


--Third and Fourth Moment Business Decision
-- skewness and kurkosis 

SELECT
    (
        SUM(POWER(tap_c - (SELECT AVG(tap_c) FROM gt_clientdata), 3)) / 
        (COUNT(*) * POWER((SELECT STDDEV(tap_c) FROM gt_clientdata), 3))
    ) AS skewness,
    (
        (SUM(POWER(tap_c - (SELECT AVG(tap_c) FROM gt_clientdata), 4)) / 
        (COUNT(*) * POWER((SELECT STDDEV(tap_c) FROM gt_clientdata), 4))) - 3
    ) AS kurtosis
FROM gt_clientdata

----------------------------------------------------------------------------------
select * from gt_clientdata

-- First Moment Business Decision 
-- it_kg Mean 
SELECT AVG(it_kg) AS mean_it_kg
FROM gt_clientdata;

--MEDIAN
SELECT it_kg AS median_it_kg
FROM (SELECT it_kg, ROW_NUMBER() OVER (ORDER BY it_kg) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM gt_clientdata
) AS subquery
WHERE row_num = (total_count + 1) / 2 OR row_num = (total_count + 2) / 2;  

--mode
 SELECT it_kg AS mode_it_kg
FROM (
    SELECT it_kg, COUNT(*) AS frequency
    FROM gt_clientdata
    GROUP BY it_kg
    ORDER BY frequency DESC
    LIMIT 1
) AS subquery;

--Second Moment Business Decision/Measures of Dispersion
--Variance
SELECT VARIANCE(it_kg) AS it_kg_variance
FROM gt_clientdata;

--Standard Deviation 
SELECT STDDEV(it_kg) AS it_kg_stddev
FROM gt_clientdata;

# Range
SELECT MAX(it_kg) - MIN(it_kg) AS it_kg_range
FROM gt_clientdata;


--Third and Fourth Moment Business Decision
-- skewness and kurkosis 

SELECT
    (
        SUM(POWER(it_kg - (SELECT AVG(it_kg) FROM gt_clientdata), 3)) / 
        (COUNT(*) * POWER((SELECT STDDEV(it_kg) FROM gt_clientdata), 3))
    ) AS skewness,
    (
        (SUM(POWER(it_kg - (SELECT AVG(it_kg) FROM gt_clientdata), 4)) / 
        (COUNT(*) * POWER((SELECT STDDEV(it_kg) FROM gt_clientdata), 4))) - 3
    ) AS kurtosis
FROM gt_clientdata
----------------------------------------------------------------------------------
select * from gt_clientdata

-- First Moment Business Decision 
-- bucket_no Mean 
SELECT AVG(bucket_no) AS mean_bucket_no
FROM gt_clientdata;

--MEDIAN
SELECT bucket_no AS median_bucket_no
FROM (SELECT bucket_no, ROW_NUMBER() OVER (ORDER BY bucket_no) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM gt_clientdata
) AS subquery
WHERE row_num = (total_count + 1) / 2 OR row_num = (total_count + 2) / 2;  

--mode
 SELECT bucket_no AS mode_bucket_no
FROM (
    SELECT bucket_no, COUNT(*) AS frequency
    FROM gt_clientdata
    GROUP BY bucket_no
    ORDER BY frequency DESC
    LIMIT 1
) AS subquery;

--Second Moment Business Decision/Measures of Dispersion
--Variance
SELECT VARIANCE(bucket_no) AS bucket_no_variance
FROM gt_clientdata;

--Standard Deviation 
SELECT STDDEV(bucket_no) AS bucket_no_stddev
FROM gt_clientdata;

# Range
SELECT MAX(bucket_no) - MIN(bucket_no) AS bucket_no_range
FROM gt_clientdata;


--Third and Fourth Moment Business Decision
-- skewness and kurkosis 

SELECT
    (
        SUM(POWER(bucket_no - (SELECT AVG(bucket_no) FROM gt_clientdata), 3)) / 
        (COUNT(*) * POWER((SELECT STDDEV(bucket_no) FROM gt_clientdata), 3))
    ) AS skewness,
    (
        (SUM(POWER(bucket_no - (SELECT AVG(bucket_no) FROM gt_clientdata), 4)) / 
        (COUNT(*) * POWER((SELECT STDDEV(bucket_no) FROM gt_clientdata), 4))) - 3
    ) AS kurtosis
FROM gt_clientdata

----------------------------------------------------------------------------------
select * from gt_clientdata

-- First Moment Business Decision 
-- static_wt Mean 
SELECT AVG(static_wt) AS mean_static_wt
FROM gt_clientdata;

--MEDIAN
SELECT static_wt AS median_static_wt
FROM (SELECT static_wt, ROW_NUMBER() OVER (ORDER BY static_wt) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM gt_clientdata
) AS subquery
WHERE row_num = (total_count + 1) / 2 OR row_num = (total_count + 2) / 2;  

--mode
 SELECT static_wt AS mode_static_wt
FROM (
    SELECT static_wt, COUNT(*) AS frequency
    FROM gt_clientdata
    GROUP BY static_wt
    ORDER BY frequency DESC
    LIMIT 1
) AS subquery;

--Second Moment Business Decision/Measures of Dispersion
--Variance
SELECT VARIANCE(static_wt) AS static_wt_variance
FROM gt_clientdata;

--Standard Deviation 
SELECT STDDEV(static_wt) AS static_wt_stddev
FROM gt_clientdata;

# Range
SELECT MAX(static_wt) - MIN(static_wt) AS static_wt_range
FROM gt_clientdata;
----------------------------------------------------------------------------------
select * from gt_clientdata

-- First Moment Business Decision 
-- lime2 Mean 
SELECT AVG(lime2) AS mean_lime2
FROM gt_clientdata;

--MEDIAN
SELECT lime2 AS median_lime2
FROM (SELECT lime, ROW_NUMBER() OVER (ORDER BY lime2) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM gt_clientdata
) AS subquery
WHERE row_num = (total_count + 1) / 2 OR row_num = (total_count + 2) / 2;  

--mode
 SELECT lime2 AS mode_lime2
FROM (
    SELECT lime2, COUNT(*) AS frequency
    FROM gt_clientdata
    GROUP BY lime2
    ORDER BY frequency DESC
    LIMIT 1
) AS subquery;

--Second Moment Business Decision/Measures of Dispersion
--Variance
SELECT VARIANCE(lime2) AS lime2_variance
FROM gt_clientdata;

--Standard Deviation 
SELECT STDDEV(lime2) AS lime2_stddev
FROM gt_clientdata;

# Range
SELECT MAX(lime2) - MIN(lime2) AS lime2_range
FROM gt_clientdata;


--Third and Fourth Moment Business Decision
-- skewness and kurkosis 

SELECT
    (
        SUM(POWER(lime2 - (SELECT AVG(lime2) FROM gt_clientdata), 3)) / 
        (COUNT(*) * POWER((SELECT STDDEV(lime2) FROM gt_clientdata), 3))
    ) AS skewness,
    (
        (SUM(POWER(lime2 - (SELECT AVG(lime2) FROM gt_clientdata), 4)) / 
        (COUNT(*) * POWER((SELECT STDDEV(lime2) FROM gt_clientdata), 4))) - 3
    ) AS kurtosis
FROM gt_clientdata
----------------------------------------------------------------------------------
select * from gt_clientdata

-- First Moment Business Decision 
-- o2side3 Mean 
SELECT AVG(o2side3) AS mean_o2side3
FROM gt_clientdata;

--MEDIAN
SELECT o2side3 AS median_o2side3
FROM (SELECT o2side3, ROW_NUMBER() OVER (ORDER BY o2side3) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM gt_clientdata
) AS subquery
WHERE row_num = (total_count + 1) / 2 OR row_num = (total_count + 2) / 2;  

--mode
 SELECT o2side3 AS mode_o2side3
FROM (
    SELECT o2side3, COUNT(*) AS frequency
    FROM gt_clientdata
    GROUP BY o2side3
    ORDER BY frequency DESC
    LIMIT 1
) AS subquery;

--Second Moment Business Decision/Measures of Dispersion
--Variance
SELECT VARIANCE(o2side3) AS o2side3_variance
FROM gt_clientdata;

--Standard Deviation 
SELECT STDDEV(o2side3) AS o2side3_stddev
FROM gt_clientdata;

# Range
SELECT MAX(o2side3) - MIN(o2side3) AS o2side3_range
FROM gt_clientdata;


--Third and Fourth Moment Business Decision
-- skewness and kurkosis 

SELECT
    (
        SUM(POWER(o2side3 - (SELECT AVG(o2side3) FROM gt_clientdata), 3)) / 
        (COUNT(*) * POWER((SELECT STDDEV(o2side3) FROM gt_clientdata), 3))
    ) AS skewness,
    (
        (SUM(POWER(o2side3 - (SELECT AVG(o2side3) FROM gt_clientdata), 4)) / 
        (COUNT(*) * POWER((SELECT STDDEV(o2side3) FROM gt_clientdata), 4))) - 3
    ) AS kurtosis
FROM gt_clientdata
-------------------------------------------------------------------------------------------------
--mode
 SELECT prev_tap_time AS mode_prev_tap_time
FROM (
    SELECT prev_tap_time, COUNT(*) AS frequency
    FROM gt_clientdata
    GROUP BY prev_tap_time
    ORDER BY frequency DESC
    LIMIT 1
) AS subquery;
-----------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------
select * from gt_clientdata

-- First Moment Business Decision 
-- tap_duration Mean 
SELECT AVG(tap_duration) AS mean_tap_duration
FROM gt_clientdata;

--MEDIAN
SELECT tap_duration AS median_tap_duration
FROM (SELECT tap_duration, ROW_NUMBER() OVER (ORDER BY tap_duration) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM gt_clientdata
) AS subquery
WHERE row_num = (total_count + 1) / 2 OR row_num = (total_count + 2) / 2;  

--mode
 SELECT tap_duration AS mode_tap_duration
FROM (
    SELECT tap_duration, COUNT(*) AS frequency
    FROM gt_clientdata
    GROUP BY tap_duration
    ORDER BY frequency DESC
    LIMIT 1
) AS subquery;

--Second Moment Business Decision/Measures of Dispersion
--Variance
SELECT VARIANCE(tap_duration) AS tap_duration_variance
FROM gt_clientdata;

--Standard Deviation 
SELECT STDDEV(tap_duration) AS tap_duration_stddev
FROM gt_clientdata;

# Range
SELECT MAX(tap_duration) - MIN(tap_duration) AS tap_duration_range
FROM gt_clientdata;


--Third and Fourth Moment Business Decision
-- skewness and kurkosis 

SELECT
    (
        SUM(POWER(tap_duration - (SELECT AVG(tap_duration) FROM gt_clientdata), 3)) / 
        (COUNT(*) * POWER((SELECT STDDEV(tap_duration) FROM gt_clientdata), 3))
    ) AS skewness,
    (
        (SUM(POWER(tap_duration - (SELECT AVG(tap_duration) FROM gt_clientdata), 4)) / 
        (COUNT(*) * POWER((SELECT STDDEV(tap_duration) FROM gt_clientdata), 4))) - 3
    ) AS kurtosis
FROM gt_clientdata

----------------------------------------------------------------------------------
select * from gt_clientdata

-- First Moment Business Decision 
-- tap_duration Mean 
SELECT AVG(tap_duration) AS mean_tap_duration
FROM gt_clientdata;

--MEDIAN
SELECT tap_duration AS median_tap_duration
FROM (SELECT tap_duration, ROW_NUMBER() OVER (ORDER BY tap_duration) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM gt_clientdata
) AS subquery
WHERE row_num = (total_count + 1) / 2 OR row_num = (total_count + 2) / 2;  

--mode
 SELECT tap_duration AS mode_tap_duration
FROM (
    SELECT tap_duration, COUNT(*) AS frequency
    FROM gt_clientdata
    GROUP BY tap_duration
    ORDER BY frequency DESC
    LIMIT 1
) AS subquery;

--Second Moment Business Decision/Measures of Dispersion
--Variance
SELECT VARIANCE(tap_duration) AS tap_duration_variance
FROM gt_clientdata;

--Standard Deviation 
SELECT STDDEV(tap_duration) AS tap_duration_stddev
FROM gt_clientdata;

# Range
SELECT MAX(tap_duration) - MIN(tap_duration) AS tap_duration_range
FROM gt_clientdata;


--Third and Fourth Moment Business Decision
-- skewness and kurkosis 

SELECT
    (
        SUM(POWER(tap_duration - (SELECT AVG(tap_duration) FROM gt_clientdata), 3)) / 
        (COUNT(*) * POWER((SELECT STDDEV(tap_duration) FROM gt_clientdata), 3))
    ) AS skewness,
    (
        (SUM(POWER(tap_duration - (SELECT AVG(tap_duration) FROM gt_clientdata), 4)) / 
        (COUNT(*) * POWER((SELECT STDDEV(tap_duration) FROM gt_clientdata), 4))) - 3
    ) AS kurtosis
FROM gt_clientdata
----------------------------------------------------------------------------------
select * from gt_clientdata

-- First Moment Business Decision 
-- pour_back_metal Mean 
SELECT AVG(pour_back_metal) AS mean_pour_back_metal
FROM gt_clientdata;

--MEDIAN
SELECT  pour_back_metal AS median_pour_back_metal
FROM (SELECT  pour_back_metal, ROW_NUMBER() OVER (ORDER BY  pour_back_metal) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM gt_clientdata
) AS subquery
WHERE row_num = (total_count + 1) / 2 OR row_num = (total_count + 2) / 2;  

--mode
 SELECT  pour_back_metal AS mode_pour_back_metal
FROM (
    SELECT  pour_back_metal, COUNT(*) AS frequency
    FROM gt_clientdata
    GROUP BY  pour_back_metal
    ORDER BY frequency DESC
    LIMIT 1
) AS subquery;

--Second Moment Business Decision/Measures of Dispersion
--Variance
SELECT VARIANCE( pour_back_metal) AS pour_back_metal_variance
FROM gt_clientdata;

--Standard Deviation 
SELECT STDDEV( pour_back_metal) AS  pour_back_metal_stddev
FROM gt_clientdata;

# Range
SELECT MAX( pour_back_metal) - MIN( pour_back_metal) AS  pour_back_metal_range
FROM gt_clientdata;


--Third and Fourth Moment Business Decision
-- skewness and kurkosis 

SELECT
    (
        SUM(POWER( pour_back_metal - (SELECT AVG(pour_back_metal) FROM gt_clientdata), 3)) / 
        (COUNT(*) * POWER((SELECT STDDEV(pour_back_metal) FROM gt_clientdata), 3))
    ) AS skewness,
    (
        (SUM(POWER( pour_back_metal - (SELECT AVG( pour_back_metal) FROM gt_clientdata), 4)) / 
        (COUNT(*) * POWER((SELECT STDDEV( pour_back_metal) FROM gt_clientdata), 4))) - 3
    ) AS kurtosis
FROM gt_clientdata;
----------------------------------------------------------------------------------
select * from gt_clientdata

-- First Moment Business Decision 
-- lm_wt Mean 
SELECT AVG(lm_wt) AS mean_lm_wt
FROM gt_clientdata;

--MEDIAN
SELECT  lm_wt AS median_lm_wt
FROM (SELECT  lm_wt, ROW_NUMBER() OVER (ORDER BY  lm_wt) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM gt_clientdata
) AS subquery
WHERE row_num = (total_count + 1) / 2 OR row_num = (total_count + 2) / 2;  

--mode
 SELECT  lm_wt AS mode_lm_wt
FROM (
    SELECT  lm_wt, COUNT(*) AS frequency
    FROM gt_clientdata
    GROUP BY  lm_wt
    ORDER BY frequency DESC
    LIMIT 1
) AS subquery;

--Second Moment Business Decision/Measures of Dispersion
--Variance
SELECT VARIANCE( lm_wt) AS lm_wt_variance
FROM gt_clientdata;

--Standard Deviation 
SELECT STDDEV( lm_wt) AS  lm_wt_stddev
FROM gt_clientdata;

# Range
SELECT MAX( lm_wt) - MIN(lm_wt) AS lm_wt_range
FROM gt_clientdata;


--Third and Fourth Moment Business Decision
-- skewness and kurkosis 

SELECT
    (
        SUM(POWER(lm_wt - (SELECT AVG(lm_wt) FROM gt_clientdata), 3)) / 
        (COUNT(*) * POWER((SELECT STDDEV(lm_wt) FROM gt_clientdata), 3))
    ) AS skewness,
    (
        (SUM(POWER(lm_wt -(SELECT AVG(lm_wt) FROM gt_clientdata), 4)) / 
        (COUNT(*) * POWER((SELECT STDDEV( lm_wt) FROM gt_clientdata), 4))) - 3
    ) AS kurtosis
FROM gt_clientdata;
----------------------------------------------------------------------------------
select * from gt_clientdata

-- First Moment Business Decision 
-- production_mt  Mean 
SELECT AVG(production_mt) AS mean_production_mt
FROM gt_clientdata;

--MEDIAN
SELECT production_mt AS median_production_mt
FROM (SELECT  production_mt, ROW_NUMBER() OVER (ORDER BY  production_mt) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM gt_clientdata
) AS subquery
WHERE row_num = (total_count + 1) / 2 OR row_num = (total_count + 2) / 2;  

--mode
 SELECT production_mt AS mode_production_mt
FROM (
    SELECT  production_mt, COUNT(*) AS frequency
    FROM gt_clientdata
    GROUP BY  production_mt
    ORDER BY frequency DESC
    LIMIT 1
) AS subquery;

--Second Moment Business Decision/Measures of Dispersion
--Variance
SELECT VARIANCE( production_mt) AS production_mt_variance
FROM gt_clientdata;

--Standard Deviation 
SELECT STDDEV( production_mt) AS  production_mt_stddev
FROM gt_clientdata;

# Range
SELECT MAX(production_mt) - MIN(production_mt) AS production_mt_range
FROM gt_clientdata;


--Third and Fourth Moment Business Decision
-- skewness and kurkosis 

SELECT
    (
        SUM(POWER(production_mt - (SELECT AVG(production_mt) FROM gt_clientdata), 3)) / 
        (COUNT(*) * POWER((SELECT STDDEV(production_mt) FROM gt_clientdata), 3))
    ) AS skewness,
    (
        (SUM(POWER(production_mt -(SELECT AVG(production_mt) FROM gt_clientdata), 4)) / 
        (COUNT(*) * POWER((SELECT STDDEV(production_mt) FROM gt_clientdata), 4))) - 3
    ) AS kurtosis
FROM gt_clientdata;

