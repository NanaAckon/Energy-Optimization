--------------Outlier Detection And Treatment----------------------

Select * from gt_clientdata where srno = 387
-----------Detection for hot_metal_from_mbf----------
WITH quartiles AS (
    SELECT 
        percentile_cont(0.25) WITHIN GROUP (ORDER BY hot_metal_from_mbf) AS q1,
        percentile_cont(0.75) WITHIN GROUP (ORDER BY hot_metal_from_mbf) AS q3
    FROM gt_clientdata
),
iqr AS (
    SELECT 
        q1,
        q3,
        (q3 - q1) AS iqr
    FROM quartiles
)
SELECT 
    hot_metal_from_mbf
FROM 
    gt_clientdata, iqr
WHERE 
    hot_metal_from_mbf< (q1 - 1.5 * iqr) OR hot_metal_from_mbf > (q3 + 1.5 * iqr);
------------------Treatment with Winsorization-------------------------------
WITH bounds AS (
    SELECT 
        percentile_cont(0.05) WITHIN GROUP (ORDER BY hot_metal_from_mbf) AS lower_bound,
        percentile_cont(0.95) WITHIN GROUP (ORDER BY hot_metal_from_mbf) AS upper_bound
    FROM gt_clientdata
)
UPDATE gt_clientdata
SET hot_metal_from_mbf = CASE
    WHEN hot_metal_from_mbf < lower_bound THEN lower_bound
    WHEN hot_metal_from_mbf > upper_bound THEN upper_bound
    ELSE hot_metal_from_mbf
END
FROM bounds;

-------------------------------Outlier detection and treatment for energy -----------------------------------------------------

WITH quartiles AS (
    SELECT 
        percentile_cont(0.25) WITHIN GROUP (ORDER BY energy) AS q1,
        percentile_cont(0.75) WITHIN GROUP (ORDER BY energy) AS q3
    FROM gt_clientdata
),
iqr AS (
    SELECT 
        q1,
        q3,
        (q3 - q1) AS iqr
    FROM quartiles
)
SELECT 
    energy
FROM 
    gt_clientdata, iqr
WHERE 
    energy< (q1 - 1.5 * iqr) OR energy > (q3 + 1.5 * iqr);

WITH bounds AS (
    SELECT 
        percentile_cont(0.05) WITHIN GROUP (ORDER BY energy) AS lower_bound,
        percentile_cont(0.95) WITHIN GROUP (ORDER BY energy) AS upper_bound
    FROM gt_clientdata
)
UPDATE gt_clientdata
SET energy = CASE
    WHEN energy < lower_bound THEN lower_bound
    WHEN energy > upper_bound THEN upper_bound
    ELSE energy
END
FROM bounds;

-------------------------------Outlier detection and treatment for inj1_qty -----------------------------------------------------

WITH quartiles AS (
    SELECT 
        percentile_cont(0.25) WITHIN GROUP (ORDER BY inj1_qty) AS q1,
        percentile_cont(0.75) WITHIN GROUP (ORDER BY inj1_qty) AS q3
    FROM gt_clientdata
),
iqr AS (
    SELECT 
        q1,
        q3,
        (q3 - q1) AS iqr
    FROM quartiles
)
SELECT 
    inj1_qty
FROM 
    gt_clientdata, iqr
WHERE 
    inj1_qty< (q1 - 1.5 * iqr) OR inj1_qty > (q3 + 1.5 * iqr);

WITH bounds AS (
    SELECT 
        percentile_cont(0.05) WITHIN GROUP (ORDER BY inj1_qty) AS lower_bound,
        percentile_cont(0.95) WITHIN GROUP (ORDER BY inj1_qty) AS upper_bound
    FROM gt_clientdata
)
UPDATE gt_clientdata
SET inj1_qty = CASE
    WHEN inj1_qty < lower_bound THEN lower_bound
    WHEN inj1_qty > upper_bound THEN upper_bound
    ELSE inj1_qty
END
FROM bounds;

-------------------------------Outlier detection and treatment for inj2_qty -----------------------------------------------------

WITH quartiles AS (
    SELECT 
        percentile_cont(0.25) WITHIN GROUP (ORDER BY inj2_qty) AS q1,
        percentile_cont(0.75) WITHIN GROUP (ORDER BY inj2_qty) AS q3
    FROM gt_clientdata
),
iqr AS (
    SELECT 
        q1,
        q3,
        (q3 - q1) AS iqr
    FROM quartiles
)
SELECT 
     inj2_qty
FROM 
    gt_clientdata, iqr
WHERE 
    inj2_qty< (q1 - 1.5 * iqr) OR inj2_qty > (q3 + 1.5 * iqr);


--Winsorization
WITH bounds AS (
    SELECT 
        percentile_cont(0.05) WITHIN GROUP (ORDER BY inj2_qty) AS lower_bound,
        percentile_cont(0.95) WITHIN GROUP (ORDER BY inj2_qty) AS upper_bound
    FROM gt_clientdata
)
UPDATE gt_clientdata
SET inj2_qty = CASE
    WHEN inj2_qty < lower_bound THEN lower_bound
    WHEN inj2_qty > upper_bound THEN upper_bound
    ELSE inj2_qty
END
FROM bounds;


---------------------------Outlier detection and treatment for dri1_qty_mt_fines---------------------
select * from gt_clientdata

WITH quartiles AS (
    SELECT 
        percentile_cont(0.25) WITHIN GROUP (ORDER BY dri2_qty_mt_fines) AS q1,
        percentile_cont(0.75) WITHIN GROUP (ORDER BY dri2_qty_mt_fines) AS q3
    FROM gt_clientdata
),
iqr AS (
    SELECT 
        q1,
        q3,
        (q3 - q1) AS iqr
    FROM quartiles
)
SELECT 
    dri2_qty_mt_fines
FROM 
    gt_clientdata, iqr
WHERE 
    dri2_qty_mt_fines< (q1 - 1.5 * iqr) OR dri2_qty_mt_fines > (q3 + 1.5 * iqr);

-----Winsorization
WITH bounds AS (
    SELECT 
        percentile_cont(0.05) WITHIN GROUP (ORDER BY dri2_qty_mt_fines) AS lower_bound,
        percentile_cont(0.95) WITHIN GROUP (ORDER BY dri2_qty_mt_fines) AS upper_bound
    FROM gt_clientdata
)
UPDATE gt_clientdata
SET dri2_qty_mt_fines = CASE
    WHEN dri2_qty_mt_fines < lower_bound THEN lower_bound
    WHEN dri2_qty_mt_fines > upper_bound THEN upper_bound
    ELSE dri2_qty_mt_fines
END
FROM bounds;

---------------------------Outlier detection and treatment for dri1_qty_mt_lumps---------------------
select * from gt_clientdata

WITH quartiles AS (
    SELECT 
        percentile_cont(0.25) WITHIN GROUP (ORDER BY dri1_qty_mt_lumps) AS q1,
        percentile_cont(0.75) WITHIN GROUP (ORDER BY dri1_qty_mt_lumps) AS q3
    FROM gt_clientdata
),
iqr AS (
    SELECT 
        q1,
        q3,
        (q3 - q1) AS iqr
    FROM quartiles
)
SELECT 
    dri1_qty_mt_lumps
FROM 
    gt_clientdata, iqr
WHERE 
    dri1_qty_mt_lumps< (q1 - 1.5 * iqr) OR dri1_qty_mt_lumps > (q3 + 1.5 * iqr);

-----Winsorization
WITH bounds AS (
    SELECT 
        percentile_cont(0.05) WITHIN GROUP (ORDER BY dri1_qty_mt_lumps) AS lower_bound,
        percentile_cont(0.95) WITHIN GROUP (ORDER BY dri1_qty_mt_lumps) AS upper_bound
    FROM gt_clientdata
)
UPDATE gt_clientdata
SET dri1_qty_mt_lumps = CASE
    WHEN dri1_qty_mt_lumps < lower_bound THEN lower_bound
    WHEN dri1_qty_mt_lumps > upper_bound THEN upper_bound
    ELSE dri1_qty_mt_lumps
END
FROM bounds;


---------------------------Outlier detection and treatment for tot_dri_qty---------------------
select * from gt_clientdata

WITH quartiles AS (
    SELECT 
        percentile_cont(0.25) WITHIN GROUP (ORDER BY tot_dri_qty) AS q1,
        percentile_cont(0.75) WITHIN GROUP (ORDER BY tot_dri_qty) AS q3
    FROM gt_clientdata
),
iqr AS (
    SELECT 
        q1,
        q3,
        (q3 - q1) AS iqr
    FROM quartiles
)
SELECT 
    tot_dri_qty
FROM 
    gt_clientdata, iqr
WHERE 
    tot_dri_qty< (q1 - 1.5 * iqr) OR tot_dri_qty > (q3 + 1.5 * iqr);

-----Winsorization
WITH bounds AS (
    SELECT 
        percentile_cont(0.05) WITHIN GROUP (ORDER BY tot_dri_qty) AS lower_bound,
        percentile_cont(0.95) WITHIN GROUP (ORDER BY tot_dri_qty) AS upper_bound
    FROM gt_clientdata
)
UPDATE gt_clientdata
SET tot_dri_qty = CASE
    WHEN tot_dri_qty < lower_bound THEN lower_bound
    WHEN tot_dri_qty > upper_bound THEN upper_bound
    ELSE tot_dri_qty
END
FROM bounds;



---------------------------Outlier detection and treatment for dolo---------------------
select * from gt_clientdata

WITH quartiles AS (
    SELECT 
        percentile_cont(0.25) WITHIN GROUP (ORDER BY dolo) AS q1,
        percentile_cont(0.75) WITHIN GROUP (ORDER BY dolo) AS q3
    FROM gt_clientdata
),
iqr AS (
    SELECT 
        q1,
        q3,
        (q3 - q1) AS iqr
    FROM quartiles
)
SELECT 
    dolo
FROM 
    gt_clientdata, iqr
WHERE 
    dolo< (q1 - 1.5 * iqr) OR dolo > (q3 + 1.5 * iqr);

-----Winsorization
WITH bounds AS (
    SELECT 
        percentile_cont(0.05) WITHIN GROUP (ORDER BY dolo) AS lower_bound,
        percentile_cont(0.95) WITHIN GROUP (ORDER BY dolo) AS upper_bound
    FROM gt_clientdata
)
UPDATE gt_clientdata
SET dolo = CASE
    WHEN dolo < lower_bound THEN lower_bound
    WHEN dolo > upper_bound THEN upper_bound
    ELSE dolo
END
FROM bounds;

---------------------------Outlier detection and treatment for dolo1_empty---------------------
select * from gt_clientdata

WITH quartiles AS (
    SELECT 
        percentile_cont(0.25) WITHIN GROUP (ORDER BY dolo1_empty) AS q1,
        percentile_cont(0.75) WITHIN GROUP (ORDER BY dolo1_empty) AS q3
    FROM gt_clientdata
),
iqr AS (
    SELECT 
        q1,
        q3,
        (q3 - q1) AS iqr
    FROM quartiles
)
SELECT 
    dolo1_empty
FROM 
    gt_clientdata, iqr
WHERE 
    dolo1_empty< (q1 - 1.5 * iqr) OR dolo1_empty > (q3 + 1.5 * iqr);

-----Winsorization
WITH bounds AS (
    SELECT 
        percentile_cont(0.05) WITHIN GROUP (ORDER BY dolo1_empty) AS lower_bound,
        percentile_cont(0.95) WITHIN GROUP (ORDER BY dolo1_empty) AS upper_bound
    FROM gt_clientdata
)
UPDATE gt_clientdata
SET dolo1_empty = CASE
    WHEN dolo1_empty < lower_bound THEN lower_bound
    WHEN dolo1_empty > upper_bound THEN upper_bound
    ELSE dolo1_empty
END
FROM bounds;

---------------------------Outlier detection and treatment for tot_lime_qty---------------------
select * from gt_clientdata

WITH quartiles AS (
    SELECT 
        percentile_cont(0.25) WITHIN GROUP (ORDER BY tot_lime_qty) AS q1,
        percentile_cont(0.75) WITHIN GROUP (ORDER BY tot_lime_qty) AS q3
    FROM gt_clientdata
),
iqr AS (
    SELECT 
        q1,
        q3,
        (q3 - q1) AS iqr
    FROM quartiles
)
SELECT 
    tot_lime_qty
FROM 
    gt_clientdata, iqr
WHERE 
    tot_lime_qty< (q1 - 1.5 * iqr) OR tot_lime_qty > (q3 + 1.5 * iqr);

-----Winsorization
WITH bounds AS (
    SELECT 
        percentile_cont(0.05) WITHIN GROUP (ORDER BY tot_lime_qty) AS lower_bound,
        percentile_cont(0.95) WITHIN GROUP (ORDER BY tot_lime_qty) AS upper_bound
    FROM gt_clientdata
)
UPDATE gt_clientdata
SET tot_lime_qty = CASE
    WHEN tot_lime_qty < lower_bound THEN lower_bound
    WHEN tot_lime_qty > upper_bound THEN upper_bound
    ELSE tot_lime_qty
END
FROM bounds;

---------------------------Outlier detection and treatment for tap_temp---------------------
select * from gt_clientdata

WITH quartiles AS (
    SELECT 
        percentile_cont(0.25) WITHIN GROUP (ORDER BY tap_temp) AS q1,
        percentile_cont(0.75) WITHIN GROUP (ORDER BY tap_temp) AS q3
    FROM gt_clientdata
),
iqr AS (
    SELECT 
        q1,
        q3,
        (q3 - q1) AS iqr
    FROM quartiles
)
SELECT 
    tap_temp
FROM 
    gt_clientdata, iqr
WHERE 
    tap_temp< (q1 - 1.5 * iqr) OR tap_temp > (q3 + 1.5 * iqr);

-----Winsorization
WITH bounds AS (
    SELECT 
        percentile_cont(0.05) WITHIN GROUP (ORDER BY tap_temp) AS lower_bound,
        percentile_cont(0.95) WITHIN GROUP (ORDER BY tap_temp) AS upper_bound
    FROM gt_clientdata
)
UPDATE gt_clientdata
SET tap_temp = CASE
    WHEN tap_temp < lower_bound THEN lower_bound
    WHEN tap_temp > upper_bound THEN upper_bound
    ELSE tap_temp
END
FROM bounds;

---------------------------Outlier detection and treatment for o2act---------------------
select * from gt_clientdata

WITH quartiles AS (
    SELECT 
        percentile_cont(0.25) WITHIN GROUP (ORDER BY o2act) AS q1,
        percentile_cont(0.75) WITHIN GROUP (ORDER BY o2act) AS q3
    FROM gt_clientdata
),
iqr AS (
    SELECT 
        q1,
        q3,
        (q3 - q1) AS iqr
    FROM quartiles
)
SELECT 
    o2act
FROM 
    gt_clientdata, iqr
WHERE 
    o2act< (q1 - 1.5 * iqr) OR o2act > (q3 + 1.5 * iqr);

-----Winsorization
WITH bounds AS (
    SELECT 
        percentile_cont(0.05) WITHIN GROUP (ORDER BY o2act) AS lower_bound,
        percentile_cont(0.95) WITHIN GROUP (ORDER BY o2act) AS upper_bound
    FROM gt_clientdata
)
UPDATE gt_clientdata
SET o2act = CASE
    WHEN o2act < lower_bound THEN lower_bound
    WHEN o2act > upper_bound THEN upper_bound
    ELSE o2act
END
FROM bounds;

---------------------------Outlier detection and treatment for kwh_per_ton---------------------
select * from gt_clientdata

WITH quartiles AS (
    SELECT 
        percentile_cont(0.25) WITHIN GROUP (ORDER BY kwh_per_ton) AS q1,
        percentile_cont(0.75) WITHIN GROUP (ORDER BY kwh_per_ton) AS q3
    FROM gt_clientdata
),
iqr AS (
    SELECT 
        q1,
        q3,
        (q3 - q1) AS iqr
    FROM quartiles
)
SELECT 
    kwh_per_ton
FROM 
    gt_clientdata, iqr
WHERE 
    kwh_per_ton < (q1 - 1.5 * iqr) OR kwh_per_ton > (q3 + 1.5 * iqr);

-----Winsorization
WITH bounds AS (
    SELECT 
        percentile_cont(0.05) WITHIN GROUP (ORDER BY kwh_per_ton) AS lower_bound,
        percentile_cont(0.95) WITHIN GROUP (ORDER BY kwh_per_ton) AS upper_bound
    FROM gt_clientdata
)
UPDATE gt_clientdata
SET kwh_per_ton = CASE
    WHEN kwh_per_ton < lower_bound THEN lower_bound
    WHEN kwh_per_ton > upper_bound THEN upper_bound
    ELSE kwh_per_ton
END
FROM bounds;

---------------------------Outlier detection and treatment for e1_cur---------------------
select * from gt_clientdata

WITH quartiles AS (
    SELECT 
        percentile_cont(0.25) WITHIN GROUP (ORDER BY e1_cur) AS q1,
        percentile_cont(0.75) WITHIN GROUP (ORDER BY e1_cur) AS q3
    FROM gt_clientdata
),
iqr AS (
    SELECT 
        q1,
        q3,
        (q3 - q1) AS iqr
    FROM quartiles
)
SELECT 
    e1_cur
FROM 
    gt_clientdata, iqr
WHERE 
    e1_cur < (q1 - 1.5 * iqr) OR e1_cur > (q3 + 1.5 * iqr);

-----Winsorization
WITH bounds AS (
    SELECT 
        percentile_cont(0.05) WITHIN GROUP (ORDER BY e1_cur) AS lower_bound,
        percentile_cont(0.95) WITHIN GROUP (ORDER BY e1_cur) AS upper_bound
    FROM gt_clientdata
)
UPDATE gt_clientdata
SET e1_cur = CASE
    WHEN e1_cur < lower_bound THEN lower_bound
    WHEN e1_cur > upper_bound THEN upper_bound
    ELSE e1_cur
END
FROM bounds;

---------------------------Outlier detection and treatment for e2_cur---------------------
select * from gt_clientdata

WITH quartiles AS (
    SELECT 
        percentile_cont(0.25) WITHIN GROUP (ORDER BY e2_cur) AS q1,
        percentile_cont(0.75) WITHIN GROUP (ORDER BY e2_cur) AS q3
    FROM gt_clientdata
),
iqr AS (
    SELECT 
        q1,
        q3,
        (q3 - q1) AS iqr
    FROM quartiles
)
SELECT 
    e2_cur
FROM 
    gt_clientdata, iqr
WHERE 
    e2_cur < (q1 - 1.5 * iqr) OR e2_cur > (q3 + 1.5 * iqr);

-----Winsorization
WITH bounds AS (
    SELECT 
        percentile_cont(0.05) WITHIN GROUP (ORDER BY e2_cur) AS lower_bound,
        percentile_cont(0.95) WITHIN GROUP (ORDER BY e2_cur) AS upper_bound
    FROM gt_clientdata
)
UPDATE gt_clientdata
SET e2_cur = CASE
    WHEN e2_cur < lower_bound THEN lower_bound
    WHEN e2_cur > upper_bound THEN upper_bound
    ELSE e2_cur
END
FROM bounds;


---------------------------Outlier detection and treatment for e3_cur---------------------
select * from gt_clientdata

WITH quartiles AS (
    SELECT 
        percentile_cont(0.25) WITHIN GROUP (ORDER BY e3_cur) AS q1,
        percentile_cont(0.75) WITHIN GROUP (ORDER BY e3_cur) AS q3
    FROM gt_clientdata
),
iqr AS (
    SELECT 
        q1,
        q3,
        (q3 - q1) AS iqr
    FROM quartiles
)
SELECT 
    e3_cur
FROM 
    gt_clientdata, iqr
WHERE 
    e3_cur < (q1 - 1.5 * iqr) OR e3_cur > (q3 + 1.5 * iqr);

-----Winsorization
WITH bounds AS (
    SELECT 
        percentile_cont(0.05) WITHIN GROUP (ORDER BY e3_cur) AS lower_bound,
        percentile_cont(0.95) WITHIN GROUP (ORDER BY e3_cur) AS upper_bound
    FROM gt_clientdata
)
UPDATE gt_clientdata
SET e3_cur = CASE
    WHEN e3_cur < lower_bound THEN lower_bound
    WHEN e3_cur > upper_bound THEN upper_bound
    ELSE e3_cur
END
FROM bounds;


---------------------------Outlier detection and treatment for it_kg---------------------
select * from gt_clientdata

WITH quartiles AS (
    SELECT 
        percentile_cont(0.25) WITHIN GROUP (ORDER BY it_kg) AS q1,
        percentile_cont(0.75) WITHIN GROUP (ORDER BY it_kg) AS q3
    FROM gt_clientdata
),
iqr AS (
    SELECT 
        q1,
        q3,
        (q3 - q1) AS iqr
    FROM quartiles
)
SELECT 
    it_kg
FROM 
    gt_clientdata, iqr
WHERE 
    it_kg < (q1 - 1.5 * iqr) OR it_kg > (q3 + 1.5 * iqr);

-----Winsorization
WITH bounds AS (
    SELECT 
        percentile_cont(0.05) WITHIN GROUP (ORDER BY it_kg) AS lower_bound,
        percentile_cont(0.95) WITHIN GROUP (ORDER BY it_kg) AS upper_bound
    FROM gt_clientdata
)
UPDATE gt_clientdata
SET it_kg = CASE
    WHEN it_kg < lower_bound THEN lower_bound
    WHEN it_kg > upper_bound THEN upper_bound
    ELSE it_kg
END
FROM bounds;

---------------------------Outlier detection and treatment for static_wt---------------------
select * from gt_clientdata

WITH quartiles AS (
    SELECT 
        percentile_cont(0.25) WITHIN GROUP (ORDER BY static_wt) AS q1,
        percentile_cont(0.75) WITHIN GROUP (ORDER BY static_wt) AS q3
    FROM gt_clientdata
),
iqr AS (
    SELECT 
        q1,
        q3,
        (q3 - q1) AS iqr
    FROM quartiles
)
SELECT 
    static_wt
FROM 
    gt_clientdata, iqr
WHERE 
    static_wt < (q1 - 1.5 * iqr) OR static_wt > (q3 + 1.5 * iqr);

-----Winsorization
WITH bounds AS (
    SELECT 
        percentile_cont(0.05) WITHIN GROUP (ORDER BY static_wt) AS lower_bound,
        percentile_cont(0.95) WITHIN GROUP (ORDER BY static_wt) AS upper_bound
    FROM gt_clientdata
)
UPDATE gt_clientdata
SET static_wt = CASE
    WHEN static_wt < lower_bound THEN lower_bound
    WHEN static_wt > upper_bound THEN upper_bound
    ELSE static_wt
END
FROM bounds;

---------------------------Outlier detection and treatment for lime---------------------
select * from gt_clientdata

WITH quartiles AS (
    SELECT 
        percentile_cont(0.25) WITHIN GROUP (ORDER BY lime) AS q1,
        percentile_cont(0.75) WITHIN GROUP (ORDER BY lime) AS q3
    FROM gt_clientdata
),
iqr AS (
    SELECT 
        q1,
        q3,
        (q3 - q1) AS iqr
    FROM quartiles
)
SELECT 
    lime
FROM 
    gt_clientdata, iqr
WHERE 
    lime < (q1 - 1.5 * iqr) OR lime > (q3 + 1.5 * iqr);

-----Winsorization
WITH bounds AS (
    SELECT 
        percentile_cont(0.05) WITHIN GROUP (ORDER BY lime) AS lower_bound,
        percentile_cont(0.95) WITHIN GROUP (ORDER BY lime) AS upper_bound
    FROM gt_clientdata
)
UPDATE gt_clientdata
SET lime = CASE
    WHEN lime < lower_bound THEN lower_bound
    WHEN lime > upper_bound THEN upper_bound
    ELSE lime
END
FROM bounds;


---------------------------Outlier detection and treatment for tap_duration---------------------
select * from gt_clientdata

WITH quartiles AS (
    SELECT 
        percentile_cont(0.25) WITHIN GROUP (ORDER BY tap_duration) AS q1,
        percentile_cont(0.75) WITHIN GROUP (ORDER BY tap_duration) AS q3
    FROM gt_clientdata
),
iqr AS (
    SELECT 
        q1,
        q3,
        (q3 - q1) AS iqr
    FROM quartiles
)
SELECT 
    tap_duration
FROM 
    gt_clientdata, iqr
WHERE 
    tap_duration < (q1 - 1.5 * iqr) OR tap_duration > (q3 + 1.5 * iqr);

-----Winsorization
WITH bounds AS (
    SELECT 
        percentile_cont(0.05) WITHIN GROUP (ORDER BY tap_duration) AS lower_bound,
        percentile_cont(0.95) WITHIN GROUP (ORDER BY tap_duration) AS upper_bound
    FROM gt_clientdata
)
UPDATE gt_clientdata
SET tap_duration = CASE
    WHEN tap_duration < lower_bound THEN lower_bound
    WHEN tap_duration > upper_bound THEN upper_bound
    ELSE tap_duration
END
FROM bounds;

---------------------------Outlier detection and treatment for tap_duration---------------------
select * from gt_clientdata

WITH quartiles AS (
    SELECT 
        percentile_cont(0.25) WITHIN GROUP (ORDER BY tap_duration) AS q1,
        percentile_cont(0.75) WITHIN GROUP (ORDER BY tap_duration) AS q3
    FROM gt_clientdata
),
iqr AS (
    SELECT 
        q1,
        q3,
        (q3 - q1) AS iqr
    FROM quartiles
)
SELECT 
    tap_duration
FROM 
    gt_clientdata, iqr
WHERE 
    tap_duration < (q1 - 1.5 * iqr) OR tap_duration > (q3 + 1.5 * iqr);

-----Winsorization
WITH bounds AS (
    SELECT 
        percentile_cont(0.05) WITHIN GROUP (ORDER BY tap_duration) AS lower_bound,
        percentile_cont(0.95) WITHIN GROUP (ORDER BY tap_duration) AS upper_bound
    FROM gt_clientdata
)
UPDATE gt_clientdata
SET tap_duration = CASE
    WHEN tap_duration < lower_bound THEN lower_bound
    WHEN tap_duration > upper_bound THEN upper_bound
    ELSE tap_duration
END
FROM bounds;

---------------------------Outlier detection and treatment for lm_wt---------------------
select * from gt_clientdata

WITH quartiles AS (
    SELECT 
        percentile_cont(0.25) WITHIN GROUP (ORDER BY lm_wt) AS q1,
        percentile_cont(0.75) WITHIN GROUP (ORDER BY lm_wt) AS q3
    FROM gt_clientdata
),
iqr AS (
    SELECT 
        q1,
        q3,
        (q3 - q1) AS iqr
    FROM quartiles
)
SELECT 
    lm_wt
FROM 
    gt_clientdata, iqr
WHERE 
    lm_wt < (q1 - 1.5 * iqr) OR lm_wt > (q3 + 1.5 * iqr);

-----Winsorization
WITH bounds AS (
    SELECT 
        percentile_cont(0.05) WITHIN GROUP (ORDER BY lm_wt) AS lower_bound,
        percentile_cont(0.95) WITHIN GROUP (ORDER BY lm_wt) AS upper_bound
    FROM gt_clientdata
)
UPDATE gt_clientdata
SET lm_wt = CASE
    WHEN lm_wt < lower_bound THEN lower_bound
    WHEN lm_wt > upper_bound THEN upper_bound
    ELSE lm_wt
END
FROM bounds;

---------------------------Outlier detection and treatment for production_mt---------------------
select * from gt_clientdata

WITH quartiles AS (
    SELECT 
        percentile_cont(0.25) WITHIN GROUP (ORDER BY  production_mt) AS q1,
        percentile_cont(0.75) WITHIN GROUP (ORDER BY  production_mt) AS q3
    FROM gt_clientdata
),
iqr AS (
    SELECT 
        q1,
        q3,
        (q3 - q1) AS iqr
    FROM quartiles
)
SELECT 
     production_mt
FROM 
    gt_clientdata, iqr
WHERE 
    production_mt < (q1 - 1.5 * iqr) OR  production_mt > (q3 + 1.5 * iqr);

-----Winsorization
WITH bounds AS (
    SELECT 
        percentile_cont(0.05) WITHIN GROUP (ORDER BY  production_mt) AS lower_bound,
        percentile_cont(0.95) WITHIN GROUP (ORDER BY  production_mt) AS upper_bound
    FROM gt_clientdata
)
UPDATE gt_clientdata
SET  production_mt = CASE
    WHEN  production_mt < lower_bound THEN lower_bound
    WHEN  production_mt > upper_bound THEN upper_bound
    ELSE  production_mt
END
FROM bounds;

---------------------------Outlier detection and treatment for production_mt---------------------
select * from gt_clientdata

WITH quartiles AS (
    SELECT 
        percentile_cont(0.25) WITHIN GROUP (ORDER BY  bp) AS q1,
        percentile_cont(0.75) WITHIN GROUP (ORDER BY  bp) AS q3
    FROM gt_clientdata
),
iqr AS (
    SELECT 
        q1,
        q3,
        (q3 - q1) AS iqr
    FROM quartiles
)
SELECT 
     bp
FROM 
    gt_clientdata, iqr
WHERE 
    bp < (q1 - 1.5 * iqr) OR  bp > (q3 + 1.5 * iqr);

-----Winsorization
WITH bounds AS (
    SELECT 
        percentile_cont(0.05) WITHIN GROUP (ORDER BY  bp) AS lower_bound,
        percentile_cont(0.95) WITHIN GROUP (ORDER BY  bp) AS upper_bound
    FROM gt_clientdata
)
UPDATE gt_clientdata
SET  bp = CASE
    WHEN  bp < lower_bound THEN lower_bound
    WHEN  bp > upper_bound THEN upper_bound
    ELSE  bp
END
FROM bounds;

---------------------------Outlier detection and treatment for bsm---------------------
select * from gt_clientdata

WITH quartiles AS (
    SELECT 
        percentile_cont(0.25) WITHIN GROUP (ORDER BY  bsm) AS q1,
        percentile_cont(0.75) WITHIN GROUP (ORDER BY  bsm) AS q3
    FROM gt_clientdata
),
iqr AS (
    SELECT 
        q1,
        q3,
        (q3 - q1) AS iqr
    FROM quartiles
)
SELECT 
     bsm
FROM 
    gt_clientdata, iqr
WHERE 
    bsm < (q1 - 1.5 * iqr) OR  bsm > (q3 + 1.5 * iqr);

-----Winsorization
WITH bounds AS (
    SELECT 
        percentile_cont(0.05) WITHIN GROUP (ORDER BY bsm) AS lower_bound,
        percentile_cont(0.95) WITHIN GROUP (ORDER BY bsm) AS upper_bound
    FROM gt_clientdata
)
UPDATE gt_clientdata
SET bsm = CASE
    WHEN bsm < lower_bound THEN lower_bound
    WHEN bsm > upper_bound THEN upper_bound
    ELSE bsm
END
FROM bounds;

---------------------------Outlier detection and treatment for skull---------------------
select * from gt_clientdata

WITH quartiles AS (
    SELECT 
        percentile_cont(0.25) WITHIN GROUP (ORDER BY  skull) AS q1,
        percentile_cont(0.75) WITHIN GROUP (ORDER BY  skull) AS q3
    FROM gt_clientdata
),
iqr AS (
    SELECT 
        q1,
        q3,
        (q3 - q1) AS iqr
    FROM quartiles
)
SELECT 
     skull
FROM 
    gt_clientdata, iqr
WHERE 
    skull < (q1 - 1.5 * iqr) OR  skull > (q3 + 1.5 * iqr);

-----Winsorization
WITH bounds AS (
    SELECT 
        percentile_cont(0.05) WITHIN GROUP (ORDER BY skull) AS lower_bound,
        percentile_cont(0.95) WITHIN GROUP (ORDER BY skull) AS upper_bound
    FROM gt_clientdata
)
UPDATE gt_clientdata
SET skull= CASE
    WHEN skull < lower_bound THEN lower_bound
    WHEN skull > upper_bound THEN upper_bound
    ELSE skull
END
FROM bounds;

---------------------------Outlier detection and treatment for hbi---------------------
select * from gt_clientdata

WITH quartiles AS (
    SELECT 
        percentile_cont(0.25) WITHIN GROUP (ORDER BY  hbi) AS q1,
        percentile_cont(0.75) WITHIN GROUP (ORDER BY  hbi) AS q3
    FROM gt_clientdata
),
iqr AS (
    SELECT 
        q1,
        q3,
        (q3 - q1) AS iqr
    FROM quartiles
)
SELECT 
     hbi
FROM 
    gt_clientdata, iqr
WHERE 
    hbi < (q1 - 1.5 * iqr) OR  hbi > (q3 + 1.5 * iqr);

-----Winsorization
WITH bounds AS (
    SELECT 
        percentile_cont(0.05) WITHIN GROUP (ORDER BY hbi) AS lower_bound,
        percentile_cont(0.95) WITHIN GROUP (ORDER BY hbi) AS upper_bound
    FROM gt_clientdata
)
UPDATE gt_clientdata
SET hbi= CASE
    WHEN hbi < lower_bound THEN lower_bound
    WHEN hbi > upper_bound THEN upper_bound
    ELSE hbi
END
FROM bounds;

---------------------------Outlier detection and treatment for others---------------------
select * from gt_clientdata

WITH quartiles AS (
    SELECT 
        percentile_cont(0.25) WITHIN GROUP (ORDER BY  others) AS q1,
        percentile_cont(0.75) WITHIN GROUP (ORDER BY  others) AS q3
    FROM gt_clientdata
),
iqr AS (
    SELECT 
        q1,
        q3,
        (q3 - q1) AS iqr
    FROM quartiles
)
SELECT 
     others
FROM 
    gt_clientdata, iqr
WHERE 
    others < (q1 - 1.5 * iqr) OR  others > (q3 + 1.5 * iqr);

-----Winsorization
WITH bounds AS (
    SELECT 
        percentile_cont(0.05) WITHIN GROUP (ORDER BY others) AS lower_bound,
        percentile_cont(0.95) WITHIN GROUP (ORDER BY others) AS upper_bound
    FROM gt_clientdata
)
UPDATE gt_clientdata
SET others= CASE
    WHEN others < lower_bound THEN lower_bound
    WHEN others > upper_bound THEN upper_bound
    ELSE others
END
FROM bounds;

---------------------------Outlier detection and treatment for scrap_qty_mt---------------------
select * from gt_clientdata

WITH quartiles AS (
    SELECT 
        percentile_cont(0.25) WITHIN GROUP (ORDER BY  scrap_qty_mt) AS q1,
        percentile_cont(0.75) WITHIN GROUP (ORDER BY  scrap_qty_mt) AS q3
    FROM gt_clientdata
),
iqr AS (
    SELECT 
        q1,
        q3,
        (q3 - q1) AS iqr
    FROM quartiles
)
SELECT 
     scrap_qty_mt
FROM 
    gt_clientdata, iqr
WHERE 
    scrap_qty_mt < (q1 - 1.5 * iqr) OR  scrap_qty_mt > (q3 + 1.5 * iqr);

-----Winsorization
WITH bounds AS (
    SELECT 
        percentile_cont(0.05) WITHIN GROUP (ORDER BY scrap_qty_mt) AS lower_bound,
        percentile_cont(0.95) WITHIN GROUP (ORDER BY scrap_qty_mt) AS upper_bound
    FROM gt_clientdata
)
UPDATE gt_clientdata
SET scrap_qty_mt= CASE
    WHEN scrap_qty_mt < lower_bound THEN lower_bound
    WHEN scrap_qty_mt > upper_bound THEN upper_bound
    ELSE scrap_qty_mt
END
FROM bounds;

---------------------------Outlier detection and treatment for pigiron---------------------
select * from gt_clientdata

WITH quartiles AS (
    SELECT 
        percentile_cont(0.25) WITHIN GROUP (ORDER BY  pigiron) AS q1,
        percentile_cont(0.75) WITHIN GROUP (ORDER BY  pigiron) AS q3
    FROM gt_clientdata
),
iqr AS (
    SELECT 
        q1,
        q3,
        (q3 - q1) AS iqr
    FROM quartiles
)
SELECT 
     pigiron
FROM 
    gt_clientdata, iqr
WHERE 
    pigiron < (q1 - 1.5 * iqr) OR  pigiron > (q3 + 1.5 * iqr);

-----Winsorization
WITH bounds AS (
    SELECT 
        percentile_cont(0.05) WITHIN GROUP (ORDER BY pigiron) AS lower_bound,
        percentile_cont(0.95) WITHIN GROUP (ORDER BY pigiron) AS upper_bound
    FROM gt_clientdata
)
UPDATE gt_clientdata
SET pigiron= CASE
    WHEN pigiron < lower_bound THEN lower_bound
    WHEN pigiron > upper_bound THEN upper_bound
    ELSE pigiron
END
FROM bounds;
---------------------------Outlier detection and treatment for c---------------------
select * from gt_clientdata

WITH quartiles AS (
    SELECT 
        percentile_cont(0.25) WITHIN GROUP (ORDER BY  c) AS q1,
        percentile_cont(0.75) WITHIN GROUP (ORDER BY  c) AS q3
    FROM gt_clientdata
),
iqr AS (
    SELECT 
        q1,
        q3,
        (q3 - q1) AS iqr
    FROM quartiles
)
SELECT 
     c
FROM 
    gt_clientdata, iqr
WHERE 
    c < (q1 - 1.5 * iqr) OR  c > (q3 + 1.5 * iqr);

-----Winsorization
WITH bounds AS (
    SELECT 
        percentile_cont(0.05) WITHIN GROUP (ORDER BY c) AS lower_bound,
        percentile_cont(0.95) WITHIN GROUP (ORDER BY c) AS upper_bound
    FROM gt_clientdata
)
UPDATE gt_clientdata
SET c= CASE
    WHEN c < lower_bound THEN lower_bound
    WHEN c > upper_bound THEN upper_bound
    ELSE c
END
FROM bounds;

---------------------------Outlier detection and treatment for si---------------------
select * from gt_clientdata

WITH quartiles AS (
    SELECT 
        percentile_cont(0.25) WITHIN GROUP (ORDER BY  si) AS q1,
        percentile_cont(0.75) WITHIN GROUP (ORDER BY  si) AS q3
    FROM gt_clientdata
),
iqr AS (
    SELECT 
        q1,
        q3,
        (q3 - q1) AS iqr
    FROM quartiles
)
SELECT 
     si
FROM 
    gt_clientdata, iqr
WHERE 
    si < (q1 - 1.5 * iqr) OR  si > (q3 + 1.5 * iqr);

-----Winsorization
WITH bounds AS (
    SELECT 
        percentile_cont(0.05) WITHIN GROUP (ORDER BY si) AS lower_bound,
        percentile_cont(0.95) WITHIN GROUP (ORDER BY si) AS upper_bound
    FROM gt_clientdata
)
UPDATE gt_clientdata
SET si= CASE
    WHEN si < lower_bound THEN lower_bound
    WHEN si > upper_bound THEN upper_bound
    ELSE si
END
FROM bounds;

---------------------------Outlier detection and treatment for si---------------------
select * from gt_clientdata

WITH quartiles AS (
    SELECT 
        percentile_cont(0.25) WITHIN GROUP (ORDER BY  si) AS q1,
        percentile_cont(0.75) WITHIN GROUP (ORDER BY  si) AS q3
    FROM gt_clientdata
),
iqr AS (
    SELECT 
        q1,
        q3,
        (q3 - q1) AS iqr
    FROM quartiles
)
SELECT 
     si
FROM 
    gt_clientdata, iqr
WHERE 
    si < (q1 - 1.5 * iqr) OR  si > (q3 + 1.5 * iqr);

-----Winsorization
WITH bounds AS (
    SELECT 
        percentile_cont(0.05) WITHIN GROUP (ORDER BY si) AS lower_bound,
        percentile_cont(0.95) WITHIN GROUP (ORDER BY si) AS upper_bound
    FROM gt_clientdata
)
UPDATE gt_clientdata
SET si= CASE
    WHEN si < lower_bound THEN lower_bound
    WHEN si > upper_bound THEN upper_bound
    ELSE si
END
FROM bounds;

---------------------------Outlier detection and treatment for mn---------------------
select * from gt_clientdata

WITH quartiles AS (
    SELECT 
        percentile_cont(0.25) WITHIN GROUP (ORDER BY  mn) AS q1,
        percentile_cont(0.75) WITHIN GROUP (ORDER BY  mn) AS q3
    FROM gt_clientdata
),
iqr AS (
    SELECT 
        q1,
        q3,
        (q3 - q1) AS iqr
    FROM quartiles
)
SELECT 
     mn
FROM 
    gt_clientdata, iqr
WHERE 
    mn < (q1 - 1.5 * iqr) OR  mn > (q3 + 1.5 * iqr);

-----Winsorization
WITH bounds AS (
    SELECT 
        percentile_cont(0.05) WITHIN GROUP (ORDER BY mn) AS lower_bound,
        percentile_cont(0.95) WITHIN GROUP (ORDER BY mn) AS upper_bound
    FROM gt_clientdata
)
UPDATE gt_clientdata
SET mn= CASE
    WHEN mn < lower_bound THEN lower_bound
    WHEN mn > upper_bound THEN upper_bound
    ELSE mn
END
FROM bounds;

---------------------------Outlier detection and treatment for p---------------------
select * from gt_clientdata

WITH quartiles AS (
    SELECT 
        percentile_cont(0.25) WITHIN GROUP (ORDER BY  p) AS q1,
        percentile_cont(0.75) WITHIN GROUP (ORDER BY  p) AS q3
    FROM gt_clientdata
),
iqr AS (
    SELECT 
        q1,
        q3,
        (q3 - q1) AS iqr
    FROM quartiles
)
SELECT 
     p
FROM 
    gt_clientdata, iqr
WHERE 
    p < (q1 - 1.5 * iqr) OR  p > (q3 + 1.5 * iqr);

-----Winsorization
WITH bounds AS (
    SELECT 
        percentile_cont(0.05) WITHIN GROUP (ORDER BY p) AS lower_bound,
        percentile_cont(0.95) WITHIN GROUP (ORDER BY p) AS upper_bound
    FROM gt_clientdata
)
UPDATE gt_clientdata
SET p= CASE
    WHEN p < lower_bound THEN lower_bound
    WHEN p > upper_bound THEN upper_bound
    ELSE p
END
FROM bounds;

---------------------------Outlier detection and treatment for s---------------------
select * from gt_clientdata

WITH quartiles AS (
    SELECT 
        percentile_cont(0.25) WITHIN GROUP (ORDER BY  s) AS q1,
        percentile_cont(0.75) WITHIN GROUP (ORDER BY  s) AS q3
    FROM gt_clientdata
),
iqr AS (
    SELECT 
        q1,
        q3,
        (q3 - q1) AS iqr
    FROM quartiles
)
SELECT 
     s
FROM 
    gt_clientdata, iqr
WHERE 
   s < (q1 - 1.5 * iqr) OR  s > (q3 + 1.5 * iqr);

-----Winsorization
WITH bounds AS (
    SELECT 
        percentile_cont(0.05) WITHIN GROUP (ORDER BY s) AS lower_bound,
        percentile_cont(0.95) WITHIN GROUP (ORDER BY s) AS upper_bound
    FROM gt_clientdata
)
UPDATE gt_clientdata
SET s= CASE
    WHEN s < lower_bound THEN lower_bound
    WHEN s > upper_bound THEN upper_bound
    ELSE s
END
FROM bounds;
---------------------------Outlier detection and treatment for cu---------------------
select * from gt_clientdata

WITH quartiles AS (
    SELECT 
        percentile_cont(0.25) WITHIN GROUP (ORDER BY cu ) AS q1,
        percentile_cont(0.75) WITHIN GROUP (ORDER BY  cu) AS q3
    FROM gt_clientdata
),
iqr AS (
    SELECT 
        q1,
        q3,
        (q3 - q1) AS iqr
    FROM quartiles
)
SELECT 
     cu
FROM 
    gt_clientdata, iqr
WHERE 
    cu < (q1 - 1.5 * iqr) OR  cu > (q3 + 1.5 * iqr);

-----Winsorization
WITH bounds AS (
    SELECT 
        percentile_cont(0.05) WITHIN GROUP (ORDER BY cu) AS lower_bound,
        percentile_cont(0.95) WITHIN GROUP (ORDER BY cu) AS upper_bound
    FROM gt_clientdata
)
UPDATE gt_clientdata
SET cu = CASE
    WHEN cu < lower_bound THEN lower_bound
    WHEN cu > upper_bound THEN upper_bound
    ELSE cu
END
FROM bounds;

---------------------------Outlier detection and treatment for cr---------------------
select * from gt_clientdata

WITH quartiles AS (
    SELECT 
        percentile_cont(0.25) WITHIN GROUP (ORDER BY cr ) AS q1,
        percentile_cont(0.75) WITHIN GROUP (ORDER BY  cr) AS q3
    FROM gt_clientdata
),
iqr AS (
    SELECT 
        q1,
        q3,
        (q3 - q1) AS iqr
    FROM quartiles
)
SELECT 
     cr
FROM 
    gt_clientdata, iqr
WHERE 
    cr < (q1 - 1.5 * iqr) OR  cr > (q3 + 1.5 * iqr);

-----Winsorization
WITH bounds AS (
    SELECT 
        percentile_cont(0.05) WITHIN GROUP (ORDER BY cr) AS lower_bound,
        percentile_cont(0.95) WITHIN GROUP (ORDER BY cr) AS upper_bound
    FROM gt_clientdata
)
UPDATE gt_clientdata
SET cr = CASE
    WHEN cr < lower_bound THEN lower_bound
    WHEN cr > upper_bound THEN upper_bound
    ELSE cr
END
FROM bounds;

---------------------------Outlier detection and treatment for ni---------------------
select * from gt_clientdata

WITH quartiles AS (
    SELECT 
        percentile_cont(0.25) WITHIN GROUP (ORDER BY ni ) AS q1,
        percentile_cont(0.75) WITHIN GROUP (ORDER BY  ni) AS q3
    FROM gt_clientdata
),
iqr AS (
    SELECT 
        q1,
        q3,
        (q3 - q1) AS iqr
    FROM quartiles
)
SELECT 
     ni
FROM 
    gt_clientdata, iqr
WHERE 
    ni < (q1 - 1.5 * iqr) OR  ni > (q3 + 1.5 * iqr);

-----Winsorization
WITH bounds AS (
    SELECT 
        percentile_cont(0.05) WITHIN GROUP (ORDER BY ni) AS lower_bound,
        percentile_cont(0.95) WITHIN GROUP (ORDER BY ni) AS upper_bound
    FROM gt_clientdata
)
UPDATE gt_clientdata
SET ni = CASE
    WHEN ni < lower_bound THEN lower_bound
    WHEN ni > upper_bound THEN upper_bound
    ELSE ni
END
FROM bounds;

---------------------------Outlier detection and treatment for n---------------------
select * from gt_clientdata

WITH quartiles AS (
    SELECT 
        percentile_cont(0.25) WITHIN GROUP (ORDER BY n) AS q1,
        percentile_cont(0.75) WITHIN GROUP (ORDER BY n) AS q3
    FROM gt_clientdata
),
iqr AS (
    SELECT 
        q1,
        q3,
        (q3 - q1) AS iqr
    FROM quartiles
)
SELECT 
     n
FROM 
    gt_clientdata, iqr
WHERE 
    n < (q1 - 1.5 * iqr) OR  n > (q3 + 1.5 * iqr);

-----Winsorization
WITH bounds AS (
    SELECT 
        percentile_cont(0.05) WITHIN GROUP (ORDER BY n) AS lower_bound,
        percentile_cont(0.95) WITHIN GROUP (ORDER BY n) AS upper_bound
    FROM gt_clientdata
)
UPDATE gt_clientdata
SET n = CASE
    WHEN n < lower_bound THEN lower_bound
    WHEN n > upper_bound THEN upper_bound
    ELSE n
END
FROM bounds;

---------------------------Outlier detection and treatment for open_c---------------------
select * from gt_clientdata

WITH quartiles AS (
    SELECT 
        percentile_cont(0.25) WITHIN GROUP (ORDER BY open_c) AS q1,
        percentile_cont(0.75) WITHIN GROUP (ORDER BY open_c) AS q3
    FROM gt_clientdata
),
iqr AS (
    SELECT 
        q1,
        q3,
        (q3 - q1) AS iqr
    FROM quartiles
)
SELECT 
     open_c
FROM 
    gt_clientdata, iqr
WHERE 
    open_c < (q1 - 1.5 * iqr) OR  open_c > (q3 + 1.5 * iqr);

-----Winsorization
WITH bounds AS (
    SELECT 
        percentile_cont(0.05) WITHIN GROUP (ORDER BY open_c) AS lower_bound,
        percentile_cont(0.95) WITHIN GROUP (ORDER BY open_c) AS upper_bound
    FROM gt_clientdata
)
UPDATE gt_clientdata
SET open_c = CASE
    WHEN open_c < lower_bound THEN lower_bound
    WHEN open_c > upper_bound THEN upper_bound
    ELSE open_c
END
FROM bounds;

---------------------------Outlier detection and treatment for tap_c---------------------
select * from gt_clientdata

WITH quartiles AS (
    SELECT 
        percentile_cont(0.25) WITHIN GROUP (ORDER BY tap_c) AS q1,
        percentile_cont(0.75) WITHIN GROUP (ORDER BY tap_c) AS q3
    FROM gt_clientdata
),
iqr AS (
    SELECT 
        q1,
        q3,
        (q3 - q1) AS iqr
    FROM quartiles
)
SELECT 
     tap_c
FROM 
    gt_clientdata, iqr
WHERE 
    tap_c < (q1 - 1.5 * iqr) OR  tap_c > (q3 + 1.5 * iqr);

-----Winsorization
WITH bounds AS (
    SELECT 
        percentile_cont(0.05) WITHIN GROUP (ORDER BY tap_c) AS lower_bound,
        percentile_cont(0.95) WITHIN GROUP (ORDER BY tap_c) AS upper_bound
    FROM gt_clientdata
)
UPDATE gt_clientdata
SET tap_c = CASE
    WHEN tap_c < lower_bound THEN lower_bound
    WHEN tap_c > upper_bound THEN upper_bound
    ELSE tap_c
END
FROM bounds;



