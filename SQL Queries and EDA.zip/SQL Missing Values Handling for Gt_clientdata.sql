-----------------Detecting And Treating Missing Values------------------------------------------

----section
SELECT section
FROM gt_clientdata
WHERE section IS NULL
  
SELECT COUNT(*)
FROM gt_clientdata
WHERE section IS NULL;

-------Mode Imputation
WITH mode_section AS (
    SELECT section
    FROM gt_clientdata
    GROUP BY section
    ORDER BY COUNT(*) DESC
    LIMIT 1
)
UPDATE gt_clientdata
SET section = (SELECT section FROM mode_section)
WHERE section IS NULL;


----lab_rep_time
SELECT lab_rep_time
FROM gt_clientdata
WHERE lab_rep_time IS NULL
  
SELECT COUNT(*)
FROM gt_clientdata
WHERE lab_rep_time IS NULL;

-----Mean imputation
UPDATE gt_clientdata
SET lab_rep_time = (SELECT AVG(lab_rep_time) FROM gt_clientdata WHERE lab_rep_time IS NOT NULL)
WHERE lab_rep_time IS NULL;


----prev_tap_time
SELECT prev_tap_time
FROM gt_clientdata
WHERE prev_tap_time IS NULL
  
SELECT COUNT(*)
FROM gt_clientdata
WHERE prev_tap_time IS NULL;

-----Mean imputation
UPDATE gt_clientdata
SET prev_tap_time = (SELECT AVG(prev_tap_time) FROM gt_clientdata WHERE prev_tap_time IS NOT NULL)
WHERE prev_tap_time IS NULL;

----production_mt
SELECT production_mt
FROM gt_clientdata
WHERE production_mt IS NULL
  
SELECT COUNT(*)
FROM gt_clientdata
WHERE production_mt IS NULL;

-----Mean imputation
UPDATE gt_clientdata
SET production_mt = (SELECT AVG(production_mt) FROM gt_clientdata WHERE production_mt IS NOT NULL)
WHERE production_mt IS NULL;

